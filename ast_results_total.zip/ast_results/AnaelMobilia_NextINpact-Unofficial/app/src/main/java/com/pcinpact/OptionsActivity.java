// isComment
package com.pcinpact;

import android.os.Bundle;
import android.preference.PreferenceActivity;
import com.pcinpact.utils.Constantes;

/**
 * isComment
 */
public class isClassOrIsInterface extends PreferenceActivity {

    @Override
    public void isMethod(Bundle isParameter) {
        // isComment
        super.isMethod(isNameExpr);
        // isComment
        Boolean isVariable = isNameExpr.isMethod(isMethod(), isNameExpr.isFieldAccessExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        if (isNameExpr) {
            // isComment
            isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        }
        isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
    }
}
