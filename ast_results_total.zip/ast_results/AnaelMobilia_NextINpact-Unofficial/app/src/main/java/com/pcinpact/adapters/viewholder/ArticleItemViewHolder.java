// isComment
package com.pcinpact.adapters.viewholder;

import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.pcinpact.items.Item;

/**
 * isComment
 */
public class isClassOrIsInterface implements ItemViewHolder {

    /**
     * isComment
     */
    public ImageView isVariable;

    /**
     * isComment
     */
    public TextView isVariable;

    /**
     * isComment
     */
    public TextView isVariable;

    /**
     * isComment
     */
    public TextView isVariable;

    /**
     * isComment
     */
    public TextView isVariable;

    /**
     * isComment
     */
    public TextView isVariable;

    /**
     * isComment
     */
    public RelativeLayout isVariable;

    /*isComment*/
    @Override
    public int isMethod() {
        return isNameExpr.isFieldAccessExpr;
    }
}
