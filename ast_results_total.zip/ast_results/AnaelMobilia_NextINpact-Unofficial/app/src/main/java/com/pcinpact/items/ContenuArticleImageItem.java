// isComment
package com.pcinpact.items;

/**
 * isComment
 */
public class isClassOrIsInterface extends ContenuArticleItem {

    /*isComment*/
    @Override
    public int isMethod() {
        return isNameExpr.isFieldAccessExpr;
    }
}
