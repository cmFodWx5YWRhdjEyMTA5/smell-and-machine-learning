// isComment
package com.pcinpact.adapters.viewholder;

import android.widget.ImageView;
import com.pcinpact.items.Item;

/**
 * isComment
 */
public class isClassOrIsInterface implements ItemViewHolder {

    /**
     * isComment
     */
    public ImageView isVariable;

    /*isComment*/
    @Override
    public int isMethod() {
        return isNameExpr.isFieldAccessExpr;
    }
}
