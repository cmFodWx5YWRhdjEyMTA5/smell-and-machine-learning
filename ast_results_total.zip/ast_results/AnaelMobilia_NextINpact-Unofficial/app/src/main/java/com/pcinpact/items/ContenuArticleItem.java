// isComment
package com.pcinpact.items;

/**
 * isComment
 */
public abstract class isClassOrIsInterface implements Item {

    /**
     * isComment
     */
    private String isVariable;

    /**
     * isComment
     */
    private int isVariable;

    /*isComment*/
    @Override
    public int isMethod() {
        return isIntegerConstant;
    }

    /**
     * isComment
     */
    public String isMethod() {
        return isNameExpr;
    }

    /**
     * isComment
     */
    public void isMethod(String isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    /**
     * isComment
     */
    public int isMethod() {
        return isNameExpr;
    }

    /**
     * isComment
     */
    public void isMethod(int isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }
}
