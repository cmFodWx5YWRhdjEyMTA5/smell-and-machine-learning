// isComment
package com.pcinpact.items;

/**
 * isComment
 */
public interface isClassOrIsInterface {

    /**
     * isComment
     */
    int isVariable = isIntegerConstant;

    /**
     * isComment
     */
    int isVariable = isIntegerConstant;

    /**
     * isComment
     */
    int isVariable = isIntegerConstant;

    /**
     * isComment
     */
    int isVariable = isIntegerConstant;

    /**
     * isComment
     */
    int isVariable = isIntegerConstant;

    /**
     * isComment
     */
    int isVariable = isIntegerConstant;

    /**
     * isComment
     */
    int isMethod();
}
