// isComment
package com.pcinpact.network;

import com.pcinpact.items.Item;
import java.util.ArrayList;

/**
 * isComment
 */
public interface isClassOrIsInterface {

    /**
     * isComment
     */
    void isMethod(final String isParameter, final ArrayList<? extends Item> isParameter);

    /**
     * isComment
     */
    void isMethod(final String isParameter);
}
