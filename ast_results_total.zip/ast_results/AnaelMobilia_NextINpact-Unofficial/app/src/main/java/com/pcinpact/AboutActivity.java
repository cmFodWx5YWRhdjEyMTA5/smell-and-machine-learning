// isComment
package com.pcinpact;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;
import com.pcinpact.utils.Constantes;

/**
 * isComment
 */
public class isClassOrIsInterface extends AppCompatActivity {

    @Override
    public void isMethod(Bundle isParameter) {
        // isComment
        super.isMethod(isNameExpr);
        // isComment
        Boolean isVariable = isNameExpr.isMethod(isMethod(), isNameExpr.isFieldAccessExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        if (isNameExpr) {
            // isComment
            isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        }
        isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        // isComment
        Toast isVariable = isNameExpr.isMethod(isMethod(), isNameExpr.isMethod(isMethod()), isNameExpr.isFieldAccessExpr);
        isNameExpr.isMethod();
    }
}
