// isComment
package com.pcinpact.items;

/**
 * isComment
 */
public class isClassOrIsInterface implements Item {

    /**
     * isComment
     */
    private String isVariable;

    /**
     * isComment
     */
    public isConstructor(String isParameter) {
        isMethod(isNameExpr);
    }

    @Override
    public int isMethod() {
        return isNameExpr.isFieldAccessExpr;
    }

    /**
     * isComment
     */
    public String isMethod() {
        return isNameExpr;
    }

    /**
     * isComment
     */
    private void isMethod(String isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }
}
