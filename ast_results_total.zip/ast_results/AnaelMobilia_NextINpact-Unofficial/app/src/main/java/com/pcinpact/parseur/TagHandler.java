// isComment
package com.pcinpact.parseur;

import android.text.Editable;
import android.text.Html;
import org.xml.sax.XMLReader;

/**
 * isComment
 */
public class isClassOrIsInterface implements Html.TagHandler {

    private boolean isVariable = true;

    private String isVariable = null;

    private int isVariable = isIntegerConstant;

    @Override
    public void isMethod(boolean isParameter, String isParameter, Editable isParameter, XMLReader isParameter) {
        // isComment
        if ("isStringConstant".isMethod(isNameExpr)) {
            isNameExpr = "isStringConstant";
        } else if ("isStringConstant".isMethod(isNameExpr)) {
            isNameExpr = "isStringConstant";
        }
        // isComment
        if ("isStringConstant".isMethod(isNameExpr)) {
            // isComment
            if ("isStringConstant".isMethod(isNameExpr)) {
                if (isNameExpr) {
                    isNameExpr.isMethod("isStringConstant");
                    isNameExpr = true;
                } else {
                    isNameExpr = true;
                }
            } else if (isNameExpr) {
                isNameExpr.isMethod("isStringConstant");
                isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr));
                isNameExpr.isMethod("isStringConstant");
                isNameExpr = true;
                isNameExpr++;
            } else {
                isNameExpr = true;
            }
        }
    }
}
