// isComment
package com.pcinpact.adapters.viewholder;

import com.pcinpact.items.Item;

/**
 * isComment
 */
public interface isClassOrIsInterface extends Item {
}
