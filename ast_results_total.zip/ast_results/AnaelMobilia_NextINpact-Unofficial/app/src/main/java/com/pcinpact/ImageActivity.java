// isComment
package com.pcinpact;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import com.pcinpact.datastorage.ImageProvider;
import com.pcinpact.utils.Constantes;

/**
 * isComment
 */
public class isClassOrIsInterface extends AppCompatActivity {

    @Override
    public void isMethod(Bundle isParameter) {
        // isComment
        super.isMethod(isNameExpr);
        // isComment
        Boolean isVariable = isNameExpr.isMethod(isMethod(), isNameExpr.isFieldAccessExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        if (isNameExpr) {
            // isComment
            isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        }
        isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        // isComment
        ImageView isVariable = (ImageView) isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        // isComment
        String isVariable = isMethod().isMethod().isMethod("isStringConstant");
        // isComment
        ImageProvider isVariable = new ImageProvider(isMethod(), isNameExpr, isIntegerConstant);
        isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr));
        // isComment
        isNameExpr.isMethod(new View.OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                isMethod();
            }
        });
    }
}
