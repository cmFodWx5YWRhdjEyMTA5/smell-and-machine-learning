// isComment
package org.tint.tasks;

import org.tint.providers.BookmarksWrapper;
import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.os.AsyncTask;

public class isClassOrIsInterface extends AsyncTask<Void, Void, Void> {

    private ContentResolver isVariable;

    private String isVariable;

    private String isVariable;

    private Bitmap isVariable;

    public isConstructor(ContentResolver isParameter, String isParameter, String isParameter, Bitmap isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
    }

    @Override
    protected Void isMethod(Void... isParameter) {
        isNameExpr.isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr);
        return null;
    }
}
