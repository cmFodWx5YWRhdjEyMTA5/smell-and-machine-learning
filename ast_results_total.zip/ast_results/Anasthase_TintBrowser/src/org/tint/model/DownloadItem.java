// isComment
package org.tint.model;

import android.app.DownloadManager.Request;
import android.net.Uri;
import android.os.Environment;

public class isClassOrIsInterface extends Request {

    private long isVariable;

    private String isVariable;

    private String isVariable;

    private Boolean isVariable;

    public isConstructor(String isParameter) {
        super(isNameExpr.isMethod(isNameExpr));
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr.isMethod(isNameExpr.isMethod("isStringConstant") + isIntegerConstant);
        isMethod(isNameExpr);
        isMethod(isNameExpr);
        isMethod(isNameExpr.isFieldAccessExpr, isNameExpr);
    }

    public long isMethod() {
        return isNameExpr;
    }

    public void isMethod(long isParameter) {
        isNameExpr = isNameExpr;
    }

    public void isMethod(String isParameter) {
        isNameExpr = isNameExpr;
        isMethod(isNameExpr);
        isMethod(isNameExpr.isFieldAccessExpr, isNameExpr);
    }

    public void isMethod(Boolean isParameter) {
        isNameExpr = isNameExpr;
        isMethod(!isNameExpr);
    }

    public Boolean isMethod() {
        return isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }
}
