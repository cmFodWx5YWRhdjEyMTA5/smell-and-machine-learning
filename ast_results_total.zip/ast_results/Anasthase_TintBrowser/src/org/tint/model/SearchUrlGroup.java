// isComment
package org.tint.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class isClassOrIsInterface {

    private String isVariable;

    private List<SearchUrlItem> isVariable;

    public isConstructor(String isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = new ArrayList<SearchUrlItem>();
    }

    public String isMethod() {
        return isNameExpr;
    }

    public List<SearchUrlItem> isMethod() {
        return isNameExpr;
    }

    public void isMethod(String isParameter, String isParameter) {
        isNameExpr.isMethod(new SearchUrlItem(isNameExpr, isNameExpr));
    }

    public void isMethod() {
        isNameExpr.isMethod(isNameExpr, new Comparator<SearchUrlItem>() {

            @Override
            public int isMethod(SearchUrlItem isParameter, SearchUrlItem isParameter) {
                return isNameExpr.isMethod().isMethod(isNameExpr.isMethod());
            }
        });
    }
}
