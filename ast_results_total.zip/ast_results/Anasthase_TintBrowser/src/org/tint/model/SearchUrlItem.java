// isComment
package org.tint.model;

public class isClassOrIsInterface {

    private String isVariable;

    private String isVariable;

    public isConstructor(String isParameter, String isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }
}
