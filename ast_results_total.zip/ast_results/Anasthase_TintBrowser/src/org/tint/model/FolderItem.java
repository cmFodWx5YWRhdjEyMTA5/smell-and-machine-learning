// isComment
package org.tint.model;

public class isClassOrIsInterface {

    private long isVariable;

    private String isVariable;

    public isConstructor(long isParameter, String isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
    }

    public long isMethod() {
        return isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }
}
