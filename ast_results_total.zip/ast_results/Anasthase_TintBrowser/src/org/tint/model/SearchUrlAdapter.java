// isComment
package org.tint.model;

import java.util.List;
import org.tint.R;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

public class isClassOrIsInterface extends BaseExpandableListAdapter {

    private Context isVariable;

    private List<SearchUrlGroup> isVariable;

    public isConstructor(Context isParameter, List<SearchUrlGroup> isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
    }

    @Override
    public Object isMethod(int isParameter, int isParameter) {
        return isNameExpr.isMethod(isNameExpr).isMethod().isMethod(isNameExpr);
    }

    @Override
    public long isMethod(int isParameter, int isParameter) {
        return isNameExpr.isMethod(isNameExpr).isMethod().isMethod(isNameExpr).isMethod();
    }

    @Override
    public View isMethod(int isParameter, int isParameter, boolean isParameter, View isParameter, ViewGroup isParameter) {
        TextView isVariable;
        if ((isNameExpr == null) || (!(isNameExpr instanceof TextView))) {
            LayoutInflater isVariable = isNameExpr.isMethod(isNameExpr);
            isNameExpr = (TextView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr, null);
        } else {
            isNameExpr = (TextView) isNameExpr;
        }
        isNameExpr.isMethod(((SearchUrlItem) isMethod(isNameExpr, isNameExpr)).isMethod());
        return isNameExpr;
    }

    @Override
    public int isMethod(int isParameter) {
        return isNameExpr.isMethod(isNameExpr).isMethod().isMethod();
    }

    @Override
    public Object isMethod(int isParameter) {
        return isNameExpr.isMethod(isNameExpr);
    }

    @Override
    public int isMethod() {
        return isNameExpr.isMethod();
    }

    @Override
    public long isMethod(int isParameter) {
        return isNameExpr.isMethod(isNameExpr).isMethod();
    }

    @Override
    public View isMethod(int isParameter, boolean isParameter, View isParameter, ViewGroup isParameter) {
        TextView isVariable;
        if ((isNameExpr == null) || (!(isNameExpr instanceof TextView))) {
            LayoutInflater isVariable = isNameExpr.isMethod(isNameExpr);
            isNameExpr = (TextView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr, null);
        } else {
            isNameExpr = (TextView) isNameExpr;
        }
        isNameExpr.isMethod(((SearchUrlGroup) isMethod(isNameExpr)).isMethod());
        return isNameExpr;
    }

    @Override
    public boolean isMethod() {
        return true;
    }

    @Override
    public boolean isMethod(int isParameter, int isParameter) {
        return true;
    }
}
