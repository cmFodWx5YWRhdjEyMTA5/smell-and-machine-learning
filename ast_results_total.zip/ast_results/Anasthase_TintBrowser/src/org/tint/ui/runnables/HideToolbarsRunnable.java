// isComment
package org.tint.ui.runnables;

import org.tint.ui.managers.LegacyPhoneUIManager;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class isClassOrIsInterface implements Runnable {

    private LegacyPhoneUIManager isVariable;

    private int isVariable;

    private boolean isVariable;

    private Handler isVariable = new Handler() {

        public void isMethod(Message isParameter) {
            if ((!isNameExpr) && (isNameExpr != null)) {
                isNameExpr.isMethod();
            }
        }
    };

    public isConstructor(LegacyPhoneUIManager isParameter, int isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
        isNameExpr = true;
    }

    public void isMethod() {
        isNameExpr = true;
    }

    @Override
    public void isMethod() {
        try {
            isNameExpr.isMethod(isNameExpr);
            isNameExpr.isMethod(isIntegerConstant);
        } catch (InterruptedException isParameter) {
            isNameExpr.isMethod("isStringConstant", isNameExpr.isMethod());
            isNameExpr.isMethod(isIntegerConstant);
        }
    }
}
