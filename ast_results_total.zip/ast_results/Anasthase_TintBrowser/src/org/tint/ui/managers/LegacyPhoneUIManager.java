// isComment
package org.tint.ui.managers;

import org.tint.R;
import org.tint.ui.activities.TintBrowserActivity;
import org.tint.ui.components.CustomWebView;
import org.tint.ui.fragments.BaseWebViewFragment;
import org.tint.ui.fragments.LegacyPhoneStartPageFragment;
import org.tint.ui.fragments.PhoneWebViewFragment;
import org.tint.ui.fragments.StartPageFragment.OnStartPageItemClickedListener;
import org.tint.ui.runnables.HideToolbarsRunnable;
import org.tint.ui.views.PhoneUrlBar;
import org.tint.ui.views.PhoneUrlBar.OnPhoneUrlBarEventListener;
import org.tint.utils.ApplicationUtils;
import org.tint.utils.Constants;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.preference.PreferenceManager;
import android.view.ActionMode;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

public class isClassOrIsInterface extends BasePhoneUIManager {

    private enum SwitchTabsMethod {

        BUTTONS, FLING, BOTH
    }

    private static final int isVariable = isIntegerConstant;

    private static final int isVariable = isIntegerConstant;

    private ImageView isVariable;

    private ImageView isVariable;

    private ImageView isVariable;

    private ImageView isVariable;

    private ImageView isVariable;

    private ImageView isVariable;

    private ImageView isVariable;

    private ImageView isVariable;

    private LinearLayout isVariable;

    private BitmapDrawable isVariable;

    private int isVariable;

    private ToolbarsAnimator isVariable;

    private GestureDetector isVariable;

    private HideToolbarsRunnable isVariable = null;

    private SwitchTabsMethod isVariable = isNameExpr.isFieldAccessExpr;

    static {
        isNameExpr = isNameExpr.isFieldAccessExpr;
    }

    public isConstructor(TintBrowserActivity isParameter) {
        super(isNameExpr);
        isMethod();
    }

    @Override
    protected void isMethod() {
        super.isMethod();
        isNameExpr.isMethod();
        isNameExpr = new GestureDetector(isNameExpr, new GestureListener());
        isMethod();
        int isVariable = isNameExpr.isMethod().isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        Drawable isVariable = isNameExpr.isMethod().isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        Bitmap isVariable = isNameExpr.isMethod(isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        Canvas isVariable = new Canvas(isNameExpr);
        isNameExpr.isMethod(isIntegerConstant, isIntegerConstant, isNameExpr, isNameExpr);
        isNameExpr.isMethod(isNameExpr);
        isNameExpr = new BitmapDrawable(isNameExpr.isMethod(), isNameExpr);
        isNameExpr = (ProgressBar) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr = (PhoneUrlBar) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnPhoneUrlBarEventListener() {

            @Override
            public void isMethod(boolean isParameter) {
                if (isNameExpr) {
                    isNameExpr.isMethod();
                } else {
                    BaseWebViewFragment isVariable = isMethod();
                    if ((isNameExpr != null) && (isNameExpr.isMethod())) {
                        isNameExpr.isMethod();
                    }
                }
            }

            @Override
            public void isMethod() {
                isMethod();
            }

            @Override
            public void isMethod() {
                if (isNameExpr.isMethod()) {
                    // isComment
                    isMethod();
                } else if (isMethod().isMethod()) {
                    isMethod().isMethod();
                } else {
                    isMethod().isMethod();
                }
            }

            @Override
            public void isMethod(boolean isParameter) {
                isNameExpr = isNameExpr;
                if (!isNameExpr) {
                    isMethod();
                }
            }
        });
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr = (ImageView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                if (isNameExpr.isMethod()) {
                    isNameExpr.isMethod();
                    isMethod();
                } else {
                    isMethod();
                }
            }
        });
        isNameExpr.isMethod(isNameExpr);
        isNameExpr = (RelativeLayout) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
            // isComment
            }
        });
        isNameExpr = (LinearLayout) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
            // isComment
            }
        });
        isNameExpr = (ImageView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                if ((!isMethod().isMethod()) && (isMethod().isMethod())) {
                    isMethod().isMethod();
                }
            }
        });
        isNameExpr.isMethod(true);
        isNameExpr = (ImageView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                if ((!isMethod().isMethod()) && (isMethod().isMethod())) {
                    isMethod().isMethod();
                }
            }
        });
        isNameExpr.isMethod(true);
        isNameExpr = (ImageView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                isMethod();
            }
        });
        isNameExpr = (ImageView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                isMethod(true, isNameExpr.isMethod(isNameExpr.isMethod()).isMethod(isNameExpr.isFieldAccessExpr, true));
            }
        });
        isNameExpr = (ImageView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                isMethod();
            }
        });
        isNameExpr = (ImageView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                isMethod();
            }
        });
        isNameExpr = (ImageView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                isMethod();
            }
        });
        isNameExpr = (ImageView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                isMethod(true);
                isMethod();
            }
        });
        isNameExpr = (ImageView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                isMethod(true);
                isMethod();
            }
        });
        isMethod();
        isNameExpr = new ToolbarsAnimator(isNameExpr, isNameExpr, isNameExpr, isNameExpr);
        isMethod();
    }

    @Override
    public void isMethod(String isParameter, boolean isParameter, boolean isParameter) {
        super.isMethod(isNameExpr, isNameExpr, isNameExpr);
        isMethod();
        isMethod();
    }

    @Override
    protected void isMethod(boolean isParameter) {
        super.isMethod(isNameExpr);
        isMethod();
    }

    @Override
    public void isMethod(WebView isParameter, String isParameter, Bitmap isParameter) {
        if (isNameExpr == isMethod()) {
            isMethod(true);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            isNameExpr.isMethod(isNameExpr);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
            isMethod();
        }
    }

    @Override
    public void isMethod(WebView isParameter, String isParameter) {
        super.isMethod(isNameExpr, isNameExpr);
        if (isNameExpr == isMethod()) {
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            isNameExpr.isMethod(isNameExpr);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
            isMethod();
            isMethod();
        }
    }

    @Override
    public boolean isMethod() {
        if (!super.isMethod()) {
            if (isNameExpr.isMethod()) {
                isNameExpr.isMethod();
                isMethod();
                return true;
            } else {
                CustomWebView isVariable = isMethod();
                if ((isNameExpr != null) && (isNameExpr.isMethod())) {
                    isNameExpr.isMethod();
                    return true;
                } else if (isMethod() && !isMethod()) {
                    isMethod();
                    return true;
                }
            }
        }
        return true;
    }

    @Override
    public boolean isMethod() {
        isMethod(true);
        isMethod();
        if (!isNameExpr.isMethod()) {
            isNameExpr.isMethod();
        }
        return true;
    }

    @Override
    public void isMethod(boolean isParameter) {
        isNameExpr = isNameExpr;
        if (!isNameExpr) {
            isMethod();
        }
    }

    @Override
    public void isMethod() {
        super.isMethod();
        isNameExpr.isMethod(isNameExpr);
    }

    @Override
    public void isMethod(ActionMode isParameter) {
        isNameExpr = isNameExpr;
        if (isNameExpr.isMethod()) {
            isNameExpr.isMethod().isMethod(isNameExpr.isMethod());
        }
    }

    @Override
    public void isMethod(ActionMode isParameter) {
        if (isNameExpr != null) {
            isNameExpr = null;
            if (isNameExpr.isMethod()) {
                isNameExpr.isMethod().isMethod(isIntegerConstant);
            }
            InputMethodManager isVariable = (InputMethodManager) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            isNameExpr.isMethod(null, isIntegerConstant);
        }
    }

    @Override
    public void isMethod(int isParameter, int isParameter, Intent isParameter) {
    }

    @Override
    public boolean isMethod(View isParameter, MotionEvent isParameter) {
        if ((!isMethod().isMethod()) && (isNameExpr.isMethod() == isNameExpr.isFieldAccessExpr)) {
            isMethod(true);
        }
        return isNameExpr.isMethod(isNameExpr);
    }

    @Override
    protected void isMethod() {
        Window isVariable = isNameExpr.isMethod();
        WindowManager.LayoutParams isVariable = isNameExpr.isMethod();
        final int isVariable = isNameExpr.isFieldAccessExpr.isFieldAccessExpr;
        if (isNameExpr.isMethod(isNameExpr).isMethod(isNameExpr.isFieldAccessExpr, true)) {
            isNameExpr.isFieldAccessExpr |= isNameExpr;
        } else {
            isNameExpr.isFieldAccessExpr &= ~isNameExpr;
        }
        isNameExpr.isMethod(isNameExpr);
    }

    @Override
    protected void isMethod() {
        CustomWebView isVariable;
        BaseWebViewFragment isVariable = isMethod();
        if ((isNameExpr != null) && (isNameExpr.isMethod())) {
            isNameExpr = null;
            if (!isNameExpr.isMethod()) {
                isMethod(true);
            }
        } else {
            isNameExpr = isMethod();
        }
        if (isNameExpr != null) {
            String isVariable = isNameExpr.isMethod();
            String isVariable = isNameExpr.isMethod();
            Bitmap isVariable = isNameExpr.isMethod();
            if ((isNameExpr != null) && (!isNameExpr.isMethod())) {
                isNameExpr.isMethod(isNameExpr);
            } else {
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
            }
            if ((isNameExpr != null) && (!isNameExpr.isMethod())) {
                isNameExpr.isMethod(isNameExpr);
                isNameExpr.isMethod(isNameExpr);
            } else {
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                isNameExpr.isMethod(null);
            }
            isMethod(isNameExpr);
            if (isNameExpr.isMethod()) {
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
            } else {
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
            }
            isMethod();
        } else {
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
            isNameExpr.isMethod(isNameExpr);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            isNameExpr.isMethod(null);
            isNameExpr.isMethod(true);
            isNameExpr.isMethod(true);
        }
        isNameExpr.isMethod(isNameExpr != null ? isNameExpr.isMethod() : true);
    }

    @Override
    protected void isMethod() {
        isNameExpr = new LegacyPhoneStartPageFragment();
        isNameExpr.isMethod(new OnStartPageItemClickedListener() {

            @Override
            public void isMethod(String isParameter) {
                isMethod(isNameExpr);
            }
        });
    }

    @Override
    public void isMethod(SharedPreferences isParameter, String isParameter) {
        super.isMethod(isNameExpr, isNameExpr);
        if (isNameExpr.isFieldAccessExpr.isMethod(isNameExpr)) {
            isMethod();
        } else if (isNameExpr.isFieldAccessExpr.isMethod(isNameExpr)) {
            isMethod();
        } else if (isNameExpr.isFieldAccessExpr.isMethod(isNameExpr)) {
            isMethod();
            isMethod();
        }
    }

    @Override
    protected void isMethod(Bitmap isParameter) {
        BitmapDrawable isVariable = isNameExpr.isMethod(isNameExpr, isNameExpr);
        if (isNameExpr != null) {
            isNameExpr.isMethod(isNameExpr);
        } else {
            isNameExpr.isMethod(isNameExpr);
        }
    }

    public void isMethod() {
        if ((!isNameExpr.isMethod()) && (!isMethod().isMethod()) && (!isNameExpr) && (!isMethod().isMethod())) {
            isMethod(true);
        }
        isNameExpr = null;
    }

    private void isMethod() {
        if (isMethod()) {
            if (isNameExpr == isIntegerConstant) {
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            } else if (isNameExpr.isMethod()) {
                isNameExpr.isMethod(isIntegerConstant);
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            }
            if (isNameExpr == isNameExpr.isMethod() - isIntegerConstant) {
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            } else if (isNameExpr.isMethod()) {
                isNameExpr.isMethod(isIntegerConstant);
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            }
        } else {
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
        }
    }

    private void isMethod() {
        if (isNameExpr > isIntegerConstant) {
            isNameExpr.isMethod();
            PhoneWebViewFragment isVariable = isNameExpr.isMethod(isNameExpr);
            isNameExpr.isMethod().isMethod();
            isNameExpr--;
            isMethod(true);
            isMethod();
        }
    }

    private void isMethod() {
        if (isNameExpr < isNameExpr.isMethod() - isIntegerConstant) {
            isNameExpr.isMethod();
            PhoneWebViewFragment isVariable = isNameExpr.isMethod(isNameExpr);
            isNameExpr.isMethod().isMethod();
            isNameExpr++;
            isMethod(true);
            isMethod();
        }
    }

    /**
     * isComment
     */
    private void isMethod(boolean isParameter) {
        if (isNameExpr) {
            if (!isNameExpr.isMethod()) {
                isNameExpr.isMethod();
                boolean isVariable = isMethod();
                isNameExpr.isMethod(isNameExpr && isNameExpr > isIntegerConstant, isNameExpr && isNameExpr < isNameExpr.isMethod() - isIntegerConstant);
            }
        } else {
            if (isNameExpr.isMethod()) {
                if (isNameExpr != null) {
                    isNameExpr.isMethod();
                }
                isNameExpr.isMethod(isNameExpr == null);
                isNameExpr.isMethod();
            }
        }
    }

    private void isMethod() {
        if (isNameExpr != null) {
            isNameExpr.isMethod();
        }
        isNameExpr = new HideToolbarsRunnable(this, isNameExpr * isIntegerConstant);
        new Thread(isNameExpr).isMethod();
    }

    private void isMethod() {
        String isVariable = isNameExpr.isMethod(isNameExpr).isMethod(isNameExpr.isFieldAccessExpr, "isStringConstant");
        if ("isStringConstant".isMethod(isNameExpr)) {
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
        } else if ("isStringConstant".isMethod(isNameExpr)) {
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
        } else if ("isStringConstant".isMethod(isNameExpr)) {
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
        }
    }

    private void isMethod() {
        String isVariable = isNameExpr.isMethod(isNameExpr).isMethod(isNameExpr.isFieldAccessExpr, "isStringConstant");
        try {
            isNameExpr = isNameExpr.isMethod(isNameExpr);
        } catch (NumberFormatException isParameter) {
            isNameExpr = isIntegerConstant;
        }
        if (isNameExpr <= isIntegerConstant) {
            isNameExpr = isIntegerConstant;
        }
    }

    private void isMethod() {
        String isVariable = isNameExpr.isMethod(isNameExpr).isMethod(isNameExpr.isFieldAccessExpr, "isStringConstant");
        if (isNameExpr.isMethod("isStringConstant")) {
            isNameExpr = isNameExpr.isFieldAccessExpr;
        } else if (isNameExpr.isMethod("isStringConstant")) {
            isNameExpr = isNameExpr.isFieldAccessExpr;
        } else if (isNameExpr.isMethod("isStringConstant")) {
            isNameExpr = isNameExpr.isFieldAccessExpr;
        } else {
            isNameExpr = isNameExpr.isFieldAccessExpr;
        }
    }

    private boolean isMethod() {
        return (isNameExpr == isNameExpr.isFieldAccessExpr) || (isNameExpr == isNameExpr.isFieldAccessExpr);
    }

    private boolean isMethod() {
        return (isNameExpr == isNameExpr.isFieldAccessExpr) || (isNameExpr == isNameExpr.isFieldAccessExpr);
    }

    private class isClassOrIsInterface extends GestureDetector.SimpleOnGestureListener {

        @Override
        public boolean isMethod(MotionEvent isParameter, MotionEvent isParameter, float isParameter, float isParameter) {
            if (isMethod()) {
                if (isNameExpr.isMethod() - isNameExpr.isMethod() <= isNameExpr) {
                    if (isNameExpr.isMethod() > (isNameExpr.isMethod() + isNameExpr)) {
                        isMethod();
                        return true;
                    }
                    // isComment
                    if (isNameExpr.isMethod() < (isNameExpr.isMethod() - isNameExpr)) {
                        isMethod();
                        return true;
                    }
                }
            }
            return super.isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr);
        }
    }
}
