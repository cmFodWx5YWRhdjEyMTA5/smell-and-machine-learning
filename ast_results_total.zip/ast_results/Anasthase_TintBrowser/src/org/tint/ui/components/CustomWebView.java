// isComment
package org.tint.ui.components;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.UUID;
import org.apache.http.HeaderElement;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicHeader;
import org.tint.R;
import org.tint.addons.AddonMenuItem;
import org.tint.controllers.Controller;
import org.tint.model.DownloadItem;
import org.tint.ui.activities.TintBrowserActivity;
import org.tint.ui.dialogs.DownloadConfirmDialog;
import org.tint.ui.fragments.BaseWebViewFragment;
import org.tint.ui.managers.UIManager;
import org.tint.utils.ApplicationUtils;
import org.tint.utils.Constants;
import org.tint.utils.UrlUtils;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebView;
import android.widget.Toast;

public class isClassOrIsInterface extends WebView implements DownloadListener, DownloadConfirmDialog.IUserActionListener {

    private UIManager isVariable;

    private Context isVariable;

    private BaseWebViewFragment isVariable;

    private boolean isVariable = true;

    private boolean isVariable = true;

    private static boolean isVariable = true;

    private static Method isVariable = null;

    public isConstructor(UIManager isParameter, boolean isParameter) {
        this(isNameExpr.isMethod(), null, isNameExpr);
        isNameExpr = isNameExpr;
    }

    // isComment
    public isConstructor(Context isParameter, AttributeSet isParameter) {
        super(isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr = isNameExpr;
    }

    public isConstructor(Context isParameter, AttributeSet isParameter, boolean isParameter) {
        super(isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
        if (!isMethod()) {
            if (!isNameExpr) {
                isMethod();
            }
            isMethod();
            isMethod();
        }
    }

    public void isMethod(BaseWebViewFragment isParameter) {
        isNameExpr = isNameExpr;
    }

    public BaseWebViewFragment isMethod() {
        return isNameExpr;
    }

    public UUID isMethod() {
        return isNameExpr.isMethod();
    }

    public boolean isMethod() {
        return isNameExpr;
    }

    public boolean isMethod() {
        return isNameExpr;
    }

    @Override
    public void isMethod(String isParameter) {
        if ((isNameExpr != null) && (isNameExpr.isMethod() > isIntegerConstant)) {
            if (isNameExpr.isMethod(isNameExpr)) {
                isNameExpr = isNameExpr.isMethod(isNameExpr);
            } else {
                isNameExpr = isNameExpr.isMethod(isNameExpr, isNameExpr);
            }
            if (isNameExpr.isFieldAccessExpr.isMethod(isNameExpr)) {
                isMethod("isStringConstant", isNameExpr.isMethod(isNameExpr, isNameExpr.isFieldAccessExpr.isFieldAccessExpr), "isStringConstant", "isStringConstant", isNameExpr.isFieldAccessExpr);
            } else {
                super.isMethod(isNameExpr);
            }
        }
    }

    public void isMethod(String isParameter) {
        super.isMethod(isNameExpr);
    }

    public void isMethod(String isParameter) {
        isNameExpr = true;
        if (!isMethod()) {
            isNameExpr.isMethod().isMethod().isMethod(isNameExpr, this, isNameExpr);
        }
    }

    public void isMethod(String isParameter) {
        isNameExpr = true;
        if (!isMethod()) {
            isNameExpr.isMethod().isMethod().isMethod(isNameExpr, this, isNameExpr);
        }
        isNameExpr.isMethod(this, isNameExpr);
    }

    @SuppressLint("isStringConstant")
    public void isMethod() {
        WebSettings isVariable = isMethod();
        SharedPreferences isVariable = isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, true));
        isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, true));
        isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, true));
        isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, true));
        isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, true));
        isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, true));
        isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, true));
        isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, isIntegerConstant));
        int isVariable = isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, isIntegerConstant);
        isNameExpr.isMethod(isNameExpr);
        isNameExpr.isMethod(isNameExpr);
        boolean isVariable = isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, true);
        isMethod(isNameExpr, "isStringConstant", isNameExpr ? "isStringConstant" : "isStringConstant");
        if (isNameExpr) {
            isMethod(isNameExpr, "isStringConstant", isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, isIntegerConstant) / isDoubleConstant));
        }
        isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr));
        isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr.isMethod())));
        isNameExpr.isMethod().isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, true));
        isNameExpr.isMethod(true);
        isNameExpr.isMethod(true);
        isNameExpr.isMethod(true);
        isNameExpr.isMethod(true);
        isNameExpr.isMethod(true);
        if (isNameExpr) {
            isNameExpr.isMethod(true);
            isNameExpr.isMethod(true);
            isNameExpr.isMethod(true);
            isNameExpr.isMethod(true);
            isNameExpr.isMethod(true);
            isNameExpr.isMethod(true);
        } else {
            // isComment
            isNameExpr.isMethod(true);
            isNameExpr.isMethod(true);
            isNameExpr.isMethod(true);
            // isComment
            isNameExpr.isMethod(isIntegerConstant * isIntegerConstant * isIntegerConstant);
            isNameExpr.isMethod(isNameExpr.isMethod("isStringConstant", isIntegerConstant).isMethod());
            isNameExpr.isMethod(isNameExpr.isMethod("isStringConstant", isIntegerConstant).isMethod());
            isNameExpr.isMethod(isNameExpr.isMethod("isStringConstant", isIntegerConstant).isMethod());
        }
        isMethod(true);
        isMethod(this);
    }

    @Override
    public void isMethod(String isParameter, String isParameter, String isParameter, String isParameter, long isParameter) {
        DownloadItem isVariable = new DownloadItem(isNameExpr);
        isNameExpr.isMethod("isStringConstant", isNameExpr.isMethod().isMethod(isNameExpr));
        String isVariable = isNameExpr.isMethod();
        BasicHeader isVariable = new BasicHeader("isStringConstant", isNameExpr);
        HeaderElement[] isVariable = isNameExpr.isMethod();
        if (isNameExpr.isFieldAccessExpr > isIntegerConstant) {
            HeaderElement isVariable = isNameExpr[isIntegerConstant];
            if (isNameExpr.isMethod().isMethod("isStringConstant")) {
                NameValuePair isVariable = isNameExpr.isMethod("isStringConstant");
                if (isNameExpr != null) {
                    isNameExpr = isNameExpr.isMethod();
                }
            }
        }
        isNameExpr.isMethod(isNameExpr);
        isNameExpr.isMethod(isMethod());
        DownloadConfirmDialog isVariable = new DownloadConfirmDialog(isMethod()).isMethod(isNameExpr).isMethod(this);
        isNameExpr.isMethod();
    }

    @Override
    public void isMethod(DownloadItem isParameter) {
        long isVariable = ((DownloadManager) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr)).isMethod(isNameExpr);
        isNameExpr.isMethod(isNameExpr);
        isNameExpr.isMethod().isMethod().isMethod(isNameExpr);
        isNameExpr.isMethod(isNameExpr, isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr), isNameExpr.isMethod()), isNameExpr.isFieldAccessExpr).isMethod();
    }

    @Override
    public void isMethod() {
    }

    private Intent isMethod(String isParameter, int isParameter, int isParameter, String isParameter) {
        Intent isVariable = new Intent(isMethod(), TintBrowserActivity.class);
        isNameExpr.isMethod(isNameExpr);
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, isNameExpr);
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, isNameExpr);
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, isNameExpr);
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, isMethod());
        return isNameExpr;
    }

    private void isMethod(ContextMenu isParameter, int isParameter, String isParameter) {
        if (!isMethod()) {
            MenuItem isVariable;
            List<AddonMenuItem> isVariable = isNameExpr.isMethod().isMethod().isMethod(this, isNameExpr, isNameExpr);
            for (AddonMenuItem isVariable : isNameExpr) {
                isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isMethod().isMethod(), isIntegerConstant, isNameExpr.isMethod());
                isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isMethod().isMethod(), isNameExpr, isNameExpr));
            }
        }
    }

    private void isMethod() {
        isMethod(new OnCreateContextMenuListener() {

            @Override
            public void isMethod(ContextMenu isParameter, View isParameter, ContextMenuInfo isParameter) {
                HitTestResult isVariable = ((WebView) isNameExpr).isMethod();
                int isVariable = isNameExpr.isMethod();
                if ((isNameExpr == isNameExpr.isFieldAccessExpr) || (isNameExpr == isNameExpr.isFieldAccessExpr) || (isNameExpr == isNameExpr.isFieldAccessExpr) || (isNameExpr == isNameExpr.isFieldAccessExpr)) {
                    MenuItem isVariable = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isMethod(isNameExpr, isNameExpr, isNameExpr.isMethod());
                    isNameExpr.isMethod(isNameExpr.isMethod());
                } else if (isNameExpr == isNameExpr.isFieldAccessExpr) {
                    MenuItem isVariable = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isMethod(isNameExpr, isNameExpr, isNameExpr.isMethod());
                    isNameExpr.isMethod(isNameExpr.isMethod());
                } else if (isNameExpr == isNameExpr.isFieldAccessExpr) {
                    Intent isVariable = new Intent(isNameExpr.isFieldAccessExpr, isNameExpr.isMethod(isNameExpr.isFieldAccessExpr + isNameExpr.isMethod()));
                    MenuItem isVariable = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isNameExpr);
                    isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr.isFieldAccessExpr, isIntegerConstant, isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                    isNameExpr.isMethod(isMethod(isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr, isNameExpr, isNameExpr.isMethod()));
                    isMethod(isNameExpr, isNameExpr, isNameExpr.isMethod());
                    isNameExpr.isMethod(isNameExpr.isMethod());
                }
            }
        });
    }

    private static void isMethod() {
        try {
            // isComment
            if (isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr > isIntegerConstant) {
                // isComment
                // isComment
                ClassLoader isVariable = CustomWebView.class.isMethod();
                Class<?> isVariable = isNameExpr.isMethod("isStringConstant");
                isNameExpr = isNameExpr.isMethod("isStringConstant", new Class[] { String.class, String.class });
            } else {
                isNameExpr = WebSettings.class.isMethod("isStringConstant", new Class[] { String.class, String.class });
            }
        } catch (NoSuchMethodException isParameter) {
            isNameExpr.isMethod("isStringConstant", "isStringConstant" + isNameExpr.isMethod());
            isNameExpr = null;
        } catch (ClassNotFoundException isParameter) {
            isNameExpr.isMethod("isStringConstant", "isStringConstant" + isNameExpr.isMethod());
            isNameExpr = null;
        }
        isNameExpr = true;
    }

    private static void isMethod(WebSettings isParameter, String isParameter, String isParameter) {
        if (isNameExpr != null) {
            try {
                isNameExpr.isMethod(isNameExpr, isNameExpr, isNameExpr);
            } catch (IllegalArgumentException isParameter) {
                isNameExpr.isMethod("isStringConstant", "isStringConstant" + isNameExpr.isMethod());
            } catch (IllegalAccessException isParameter) {
                isNameExpr.isMethod("isStringConstant", "isStringConstant" + isNameExpr.isMethod());
            } catch (InvocationTargetException isParameter) {
                isNameExpr.isMethod("isStringConstant", "isStringConstant" + isNameExpr.isMethod());
            }
        }
    }
}
