// isComment
package org.tint.ui.preferences;

import org.tint.R;
import android.os.Bundle;
import android.preference.PreferenceFragment;

public class isClassOrIsInterface extends PreferenceFragment {

    @Override
    public void isMethod(Bundle isParameter) {
        super.isMethod(isNameExpr);
        isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
    }
}
