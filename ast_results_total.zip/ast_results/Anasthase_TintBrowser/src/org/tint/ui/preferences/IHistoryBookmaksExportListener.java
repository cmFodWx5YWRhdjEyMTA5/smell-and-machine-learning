// isComment
package org.tint.ui.preferences;

public interface isClassOrIsInterface {

    void isMethod(int isParameter, int isParameter, int isParameter);

    void isMethod(String isParameter);
}
