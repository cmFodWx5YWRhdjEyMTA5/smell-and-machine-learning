// isComment
package org.tint.ui.preferences;

import org.tint.R;
import org.tint.utils.Constants;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;

public class isClassOrIsInterface extends PreferenceFragment implements OnSharedPreferenceChangeListener {

    private Preference isVariable;

    @Override
    public void isMethod(Bundle isParameter) {
        super.isMethod(isNameExpr);
        isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr = isMethod(isNameExpr.isFieldAccessExpr);
        isMethod();
        isMethod().isMethod().isMethod(this);
    }

    @Override
    public void isMethod() {
        isMethod().isMethod().isMethod(this);
        super.isMethod();
    }

    @Override
    public void isMethod(SharedPreferences isParameter, String isParameter) {
        if (isNameExpr.isFieldAccessExpr.isMethod(isNameExpr)) {
            isMethod();
        }
    }

    private void isMethod() {
        boolean isVariable = isMethod().isMethod().isMethod(isNameExpr.isFieldAccessExpr, true);
        isNameExpr.isMethod(isNameExpr);
    }
}
