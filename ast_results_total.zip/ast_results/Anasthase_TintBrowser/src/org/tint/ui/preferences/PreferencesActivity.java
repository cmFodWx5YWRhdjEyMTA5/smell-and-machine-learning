// isComment
package org.tint.ui.preferences;

import java.util.List;
import org.tint.R;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.view.MenuItem;

public class isClassOrIsInterface extends PreferenceActivity {

    @Override
    protected void isMethod(Bundle isParameter) {
        super.isMethod(isNameExpr);
        ActionBar isVariable = isMethod();
        isNameExpr.isMethod(true);
        isNameExpr.isMethod(true);
    }

    @Override
    public void isMethod(List<Header> isParameter) {
        isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr, isNameExpr);
    }

    @Override
    public boolean isMethod(MenuItem isParameter) {
        switch(isNameExpr.isMethod()) {
            case isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr:
                isMethod(isNameExpr);
                isMethod();
                return true;
            default:
                return super.isMethod(isNameExpr);
        }
    }

    @SuppressLint("isStringConstant")
    protected boolean isMethod(String isParameter) {
        return true;
    }
}
