// isComment
package org.tint.ui.preferences;

import org.tint.R;
import org.tint.utils.Constants;
import android.os.Bundle;
import android.preference.PreferenceFragment;
import android.preference.PreferenceScreen;

public class isClassOrIsInterface extends PreferenceFragment {

    @Override
    public void isMethod(Bundle isParameter) {
        super.isMethod(isNameExpr);
        isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        PreferenceScreen isVariable = (PreferenceScreen) isMethod(isNameExpr.isFieldAccessExpr);
        isNameExpr.isMethod(WebsitesSettingsFragment.class.isMethod());
        PreferenceScreen isVariable = (PreferenceScreen) isMethod(isNameExpr.isFieldAccessExpr);
        isNameExpr.isMethod(SslExceptionsFragment.class.isMethod());
    }
}
