// isComment
package org.tint.ui.dialogs;

import org.tint.R;
import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class isClassOrIsInterface extends Dialog {

    protected Context isVariable;

    protected TextView isVariable;

    protected CheckBox isVariable;

    protected Button isVariable;

    protected Button isVariable;

    public isConstructor(Context isParameter) {
        super(isNameExpr);
        isNameExpr = isNameExpr;
        isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr = (TextView) isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr = (CheckBox) isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr = (Button) isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr = (Button) isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
    }

    public void isMethod(String isParameter) {
        isNameExpr.isMethod(isNameExpr);
    }

    public void isMethod(int isParameter) {
        isNameExpr.isMethod(isNameExpr);
    }

    public void isMethod(String isParameter) {
        isNameExpr.isMethod(isNameExpr);
    }

    public void isMethod(int isParameter) {
        isNameExpr.isMethod(isNameExpr);
    }

    public void isMethod(View.OnClickListener isParameter) {
        isNameExpr.isMethod(isNameExpr);
    }

    public void isMethod(View.OnClickListener isParameter) {
        isNameExpr.isMethod(isNameExpr);
    }

    public void isMethod(String isParameter) {
        isNameExpr.isMethod(isNameExpr);
    }

    public void isMethod(int isParameter) {
        isNameExpr.isMethod(isNameExpr);
    }

    public boolean isMethod() {
        return isNameExpr.isMethod();
    }

    public void isMethod(boolean isParameter) {
        isNameExpr.isMethod(isNameExpr);
    }
}
