// isComment
package org.tint.ui.dialogs;

import org.tint.R;
import android.content.Context;
import android.view.View;
import android.webkit.GeolocationPermissions.Callback;

public class isClassOrIsInterface extends YesNoRememberDialog {

    private String isVariable;

    private Callback isVariable;

    public isConstructor(Context isParameter) {
        super(isNameExpr);
        isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isMethod(new View.OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                if (isNameExpr != null) {
                    isNameExpr.isMethod(isNameExpr, true, isNameExpr.isMethod());
                }
                isMethod();
            }
        });
        isMethod(new View.OnClickListener() {

            @Override
            public void isMethod(View isParameter) {
                if (isNameExpr != null) {
                    isNameExpr.isMethod(isNameExpr, true, isNameExpr.isMethod());
                }
                isMethod();
            }
        });
    }

    public void isMethod(String isParameter, Callback isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
        isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr), isNameExpr));
        isNameExpr.isMethod(true);
    }
}
