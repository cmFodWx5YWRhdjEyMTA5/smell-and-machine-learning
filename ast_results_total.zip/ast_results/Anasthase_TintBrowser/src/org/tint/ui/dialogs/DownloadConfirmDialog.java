// isComment
package org.tint.ui.dialogs;

import org.tint.R;
import org.tint.model.DownloadItem;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

public class isClassOrIsInterface {

    final Context isVariable;

    final AlertDialog.Builder isVariable;

    final View isVariable;

    IUserActionListener isVariable;

    DownloadItem isVariable;

    public isConstructor(Context isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr.isMethod(isNameExpr).isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr, null);
        isNameExpr = new AlertDialog.Builder(isNameExpr).isMethod(isNameExpr).isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
    }

    public DownloadConfirmDialog isMethod(DownloadItem isParameter) {
        isNameExpr = isNameExpr;
        ((TextView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr)).isMethod(isNameExpr.isMethod());
        ((TextView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr)).isMethod(isNameExpr.isMethod());
        ((CheckBox) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr)).isMethod(isNameExpr.isMethod());
        return this;
    }

    public DownloadConfirmDialog isMethod(IUserActionListener isParameter) {
        isNameExpr = isNameExpr;
        return this;
    }

    public void isMethod() {
        isNameExpr.isMethod(isNameExpr.isMethod().isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr), new OnClickListener() {

            @Override
            public void isMethod(DialogInterface isParameter, int isParameter) {
                isMethod();
            }
        });
        isNameExpr.isMethod(isNameExpr.isMethod().isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr), new OnClickListener() {

            @Override
            public void isMethod(DialogInterface isParameter, int isParameter) {
                isMethod();
            }
        });
        isNameExpr.isMethod();
    }

    private void isMethod() {
        isNameExpr.isMethod(((CheckBox) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr)).isMethod());
        isNameExpr.isMethod(isNameExpr);
    }

    private void isMethod() {
        isNameExpr.isMethod();
    }

    public static interface isClassOrIsInterface {

        public void isMethod(DownloadItem isParameter);

        public void isMethod();
    }
}
