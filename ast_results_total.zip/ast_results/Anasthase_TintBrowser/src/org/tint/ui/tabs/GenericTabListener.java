// isComment
package org.tint.ui.tabs;

import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;

public class isClassOrIsInterface<T extends Fragment> implements ActionBar.TabListener {

    private Fragment isVariable;

    private Activity isVariable;

    private String isVariable;

    private Class<T> isVariable;

    /**
     * isComment
     */
    public isConstructor(Activity isParameter, String isParameter, Class<T> isParameter) {
        this(isNameExpr, isNameExpr, isNameExpr, null);
    }

    public isConstructor(Activity isParameter, String isParameter, Class<T> isParameter, Bundle isParameter) {
        isNameExpr = null;
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
        // isComment
        // isComment
        // isComment
        isNameExpr = isNameExpr.isMethod().isMethod(isNameExpr);
        if (isNameExpr != null && !isNameExpr.isMethod()) {
            FragmentTransaction isVariable = isNameExpr.isMethod().isMethod();
            isNameExpr.isMethod(isNameExpr);
            isNameExpr.isMethod();
        }
    }

    @Override
    public void isMethod(Tab isParameter, FragmentTransaction isParameter) {
    }

    @Override
    public void isMethod(Tab isParameter, FragmentTransaction isParameter) {
        // isComment
        if (isNameExpr == null) {
            // isComment
            isNameExpr = isNameExpr.isMethod(isNameExpr, isNameExpr.isMethod());
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr, isNameExpr, isNameExpr);
        } else {
            // isComment
            isNameExpr.isMethod(isNameExpr);
        }
    }

    @Override
    public void isMethod(Tab isParameter, FragmentTransaction isParameter) {
        if (isNameExpr != null) {
            // isComment
            isNameExpr.isMethod(isNameExpr);
        }
    }
}
