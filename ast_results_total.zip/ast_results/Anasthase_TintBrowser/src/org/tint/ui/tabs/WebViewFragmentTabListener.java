// isComment
package org.tint.ui.tabs;

import org.tint.R;
import org.tint.ui.fragments.TabletWebViewFragment;
import org.tint.ui.managers.TabletUIManager;
import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.FragmentTransaction;

public class isClassOrIsInterface implements ActionBar.TabListener {

    private TabletUIManager isVariable;

    private TabletWebViewFragment isVariable;

    private boolean isVariable;

    public isConstructor(TabletUIManager isParameter, TabletWebViewFragment isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
        isNameExpr = true;
    }

    @Override
    public void isMethod(Tab isParameter, FragmentTransaction isParameter) {
    }

    @Override
    public void isMethod(Tab isParameter, FragmentTransaction isParameter) {
        if (isNameExpr.isMethod()) {
            isNameExpr.isMethod(isNameExpr.isMethod());
        } else {
            if (!isNameExpr) {
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr, isNameExpr, null);
                isNameExpr = true;
            } else {
                isNameExpr.isMethod(isNameExpr);
            }
        }
        isNameExpr.isMethod(isNameExpr);
        isNameExpr.isMethod(isNameExpr);
    }

    @Override
    public void isMethod(Tab isParameter, FragmentTransaction isParameter) {
        if (isNameExpr.isMethod()) {
            isNameExpr.isMethod(isNameExpr.isMethod());
        } else {
            isNameExpr.isMethod(isNameExpr);
        }
    }
}
