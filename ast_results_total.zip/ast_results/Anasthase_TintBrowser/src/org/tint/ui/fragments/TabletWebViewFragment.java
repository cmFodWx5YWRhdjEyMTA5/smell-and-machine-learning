// isComment
package org.tint.ui.fragments;

import org.tint.R;
import org.tint.ui.managers.UIManager;
import android.app.ActionBar.Tab;
import android.text.TextUtils;
import android.webkit.WebView;

public class isClassOrIsInterface extends PhoneWebViewFragment {

    private Tab isVariable;

    public isConstructor() {
        super();
    }

    public void isMethod(UIManager isParameter, Tab isParameter, boolean isParameter, String isParameter) {
        isNameExpr = isNameExpr;
        isMethod(isNameExpr, isNameExpr, isNameExpr);
    }

    public void isMethod(Tab isParameter) {
        isNameExpr = isNameExpr;
        if (isNameExpr != null) {
            isNameExpr.isMethod();
        }
    }

    public Tab isMethod() {
        return isNameExpr;
    }

    public void isMethod(WebView isParameter, String isParameter) {
        if (isNameExpr == isNameExpr) {
            if (!isNameExpr.isMethod(isNameExpr)) {
                isNameExpr.isMethod(isMethod(isNameExpr));
            } else {
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
            }
        }
    }

    private String isMethod(String isParameter) {
        int isVariable = isNameExpr.isMethod().isMethod().isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        if (isNameExpr.isMethod() > isNameExpr) {
            isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr) + 'isStringConstant';
        }
        return isNameExpr;
    }
}
