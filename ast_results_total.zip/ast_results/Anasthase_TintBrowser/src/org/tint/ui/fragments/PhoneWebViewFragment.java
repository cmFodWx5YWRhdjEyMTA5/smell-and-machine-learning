// isComment
package org.tint.ui.fragments;

import org.tint.R;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class isClassOrIsInterface extends BaseWebViewFragment {

    public isConstructor() {
        super();
    }

    @Override
    public View isMethod(LayoutInflater isParameter, ViewGroup isParameter, Bundle isParameter) {
        if (isNameExpr == null) {
            isNameExpr = (ViewGroup) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr, isNameExpr, true);
        }
        isMethod();
        return isNameExpr;
    }
}
