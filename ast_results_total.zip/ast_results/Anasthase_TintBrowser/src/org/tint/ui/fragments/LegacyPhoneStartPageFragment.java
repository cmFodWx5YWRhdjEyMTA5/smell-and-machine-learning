// isComment
package org.tint.ui.fragments;

import org.tint.R;

public class isClassOrIsInterface extends StartPageFragment {

    @Override
    protected int isMethod() {
        return isNameExpr.isFieldAccessExpr.isFieldAccessExpr;
    }
}
