// isComment
package org.tint.addons;

import java.util.List;
import org.tint.addons.framework.Action;

public class isClassOrIsInterface {

    private Addon isVariable;

    private List<Action> isVariable;

    public isConstructor(Addon isParameter, List<Action> isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
    }

    public Addon isMethod() {
        return isNameExpr;
    }

    public List<Action> isMethod() {
        return isNameExpr;
    }
}
