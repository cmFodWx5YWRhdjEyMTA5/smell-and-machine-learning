// isComment
package org.tint.addons.executors;

import java.util.UUID;
import org.tint.addons.framework.Action;
import org.tint.addons.framework.LoadUrlAction;
import android.text.TextUtils;

public class isClassOrIsInterface extends BaseActionExecutor {

    private LoadUrlAction isVariable;

    @Override
    protected void isMethod(Action isParameter) {
        isNameExpr = (LoadUrlAction) isNameExpr;
    }

    @Override
    protected void isMethod() {
        String isVariable = isNameExpr.isMethod();
        String isVariable = isNameExpr.isMethod();
        if (isNameExpr.isMethod(isNameExpr)) {
            if (isNameExpr != null) {
                if (isNameExpr.isMethod()) {
                    isNameExpr.isMethod(isNameExpr);
                } else {
                    if (isNameExpr.isMethod(isNameExpr)) {
                        isNameExpr.isMethod();
                    } else {
                        isNameExpr.isMethod(isNameExpr);
                    }
                }
            }
        } else {
            UUID isVariable;
            try {
                isNameExpr = isNameExpr.isMethod(isNameExpr);
            } catch (NullPointerException isParameter) {
                isNameExpr = null;
            } catch (IllegalArgumentException isParameter) {
                isNameExpr = null;
            }
            if (isNameExpr != null) {
                if (isNameExpr.isMethod()) {
                    isNameExpr.isMethod(isNameExpr, isNameExpr, true);
                } else {
                    if (isNameExpr.isMethod(isNameExpr)) {
                        isNameExpr.isMethod(isNameExpr, true);
                    } else {
                        isNameExpr.isMethod(isNameExpr, isNameExpr, true);
                    }
                }
            }
        }
    }
}
