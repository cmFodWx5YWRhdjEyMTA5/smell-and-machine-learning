// isComment
package org.tint.addons.executors;

import org.tint.R;
import org.tint.addons.framework.Action;
import org.tint.addons.framework.AskUserInputAction;
import org.tint.controllers.Controller;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class isClassOrIsInterface extends BaseActionExecutor {

    private AskUserInputAction isVariable;

    private LayoutInflater isVariable = null;

    private View isVariable = null;

    private TextView isVariable;

    private EditText isVariable;

    @Override
    protected void isMethod(Action isParameter) {
        isNameExpr = (AskUserInputAction) isNameExpr;
        if (isNameExpr == null) {
            isNameExpr = (LayoutInflater) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
        }
    }

    @Override
    protected void isMethod() {
        isNameExpr = isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr, null);
        isNameExpr = (TextView) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr = (EditText) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        AlertDialog.Builder isVariable = new AlertDialog.Builder(isNameExpr);
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(true);
        isNameExpr.isMethod(isNameExpr.isMethod());
        isNameExpr.isMethod(isNameExpr.isMethod());
        isNameExpr.isMethod(isNameExpr.isMethod());
        isNameExpr.isMethod(isNameExpr.isMethod());
        isNameExpr.isMethod(isNameExpr.isMethod());
        isNameExpr.isMethod(isNameExpr);
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr, new OnClickListener() {

            @Override
            public void isMethod(DialogInterface isParameter, int isParameter) {
                isNameExpr.isMethod().isMethod().isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr.isMethod(), true, isNameExpr.isMethod().isMethod());
            }
        });
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr, new OnClickListener() {

            @Override
            public void isMethod(DialogInterface isParameter, int isParameter) {
                isNameExpr.isMethod().isMethod().isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr.isMethod(), true, null);
            }
        });
        isNameExpr.isMethod(new OnCancelListener() {

            @Override
            public void isMethod(DialogInterface isParameter) {
                isNameExpr.isMethod().isMethod().isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr.isMethod(), true, null);
            }
        });
        AlertDialog isVariable = isNameExpr.isMethod();
        isNameExpr.isMethod();
    }
}
