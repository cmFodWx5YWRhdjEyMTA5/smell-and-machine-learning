// isComment
package org.tint.addons.executors;

import org.tint.R;
import org.tint.addons.framework.Action;
import org.tint.addons.framework.AskUserChoiceAction;
import org.tint.controllers.Controller;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;

public class isClassOrIsInterface extends BaseActionExecutor {

    private AskUserChoiceAction isVariable;

    @Override
    protected void isMethod(Action isParameter) {
        isNameExpr = (AskUserChoiceAction) isNameExpr;
    }

    @Override
    protected void isMethod() {
        AlertDialog.Builder isVariable = new AlertDialog.Builder(isNameExpr);
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(isNameExpr.isMethod());
        isNameExpr.isMethod(isNameExpr.isMethod().isMethod(new String[isNameExpr.isMethod().isMethod()]), isIntegerConstant, new OnClickListener() {

            @Override
            public void isMethod(DialogInterface isParameter, int isParameter) {
                isNameExpr.isMethod();
                isNameExpr.isMethod().isMethod().isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr.isMethod(), true, isNameExpr);
            }
        });
        isNameExpr.isMethod(true);
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr, new OnClickListener() {

            @Override
            public void isMethod(DialogInterface isParameter, int isParameter) {
                isNameExpr.isMethod().isMethod().isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr.isMethod(), true, -isIntegerConstant);
            }
        });
        isNameExpr.isMethod(new OnCancelListener() {

            @Override
            public void isMethod(DialogInterface isParameter) {
                isNameExpr.isMethod().isMethod().isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr.isMethod(), true, -isIntegerConstant);
            }
        });
        AlertDialog isVariable = isNameExpr.isMethod();
        isNameExpr.isMethod();
    }
}
