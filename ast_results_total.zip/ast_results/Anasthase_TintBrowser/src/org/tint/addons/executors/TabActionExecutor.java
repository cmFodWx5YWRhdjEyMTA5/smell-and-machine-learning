// isComment
package org.tint.addons.executors;

import java.util.UUID;
import org.tint.addons.framework.Action;
import org.tint.addons.framework.TabAction;
import org.tint.ui.components.CustomWebView;
import android.text.TextUtils;

public class isClassOrIsInterface extends BaseActionExecutor {

    private TabAction isVariable;

    @Override
    protected void isMethod(Action isParameter) {
        isNameExpr = (TabAction) isNameExpr;
    }

    @Override
    protected void isMethod() {
        String isVariable = isNameExpr.isMethod();
        UUID isVariable;
        CustomWebView isVariable;
        // isComment
        if (!isNameExpr.isMethod(isNameExpr)) {
            try {
                isNameExpr = isNameExpr.isMethod(isNameExpr);
                isNameExpr = isNameExpr.isMethod(isNameExpr);
            } catch (NullPointerException isParameter) {
                isNameExpr = null;
                isNameExpr = null;
            } catch (IllegalArgumentException isParameter) {
                isNameExpr = null;
                isNameExpr = null;
            }
        } else {
            isNameExpr = null;
            isNameExpr = isNameExpr;
        }
        switch(isNameExpr.isMethod()) {
            case isNameExpr.isFieldAccessExpr:
                if (isNameExpr.isMethod(isNameExpr)) {
                    isNameExpr.isMethod();
                } else {
                    isNameExpr.isMethod(isNameExpr);
                }
                break;
            case isNameExpr.isFieldAccessExpr:
                if (isNameExpr != null) {
                    isNameExpr.isMethod();
                }
                break;
            case isNameExpr.isFieldAccessExpr:
                if (isNameExpr != null) {
                    isNameExpr.isMethod();
                }
                break;
            case isNameExpr.isFieldAccessExpr:
                if ((isNameExpr != null) && (isNameExpr.isMethod())) {
                    isNameExpr.isMethod();
                }
                break;
            case isNameExpr.isFieldAccessExpr:
                if ((isNameExpr != null) && (isNameExpr.isMethod())) {
                    isNameExpr.isMethod();
                }
                break;
            default:
                break;
        }
    }
}
