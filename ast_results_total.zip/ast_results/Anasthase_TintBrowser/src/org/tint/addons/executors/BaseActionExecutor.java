// isComment
package org.tint.addons.executors;

import org.tint.addons.Addon;
import org.tint.addons.framework.Action;
import org.tint.ui.components.CustomWebView;
import org.tint.ui.managers.UIManager;
import android.content.Context;

public abstract class isClassOrIsInterface {

    protected Context isVariable;

    protected UIManager isVariable;

    protected CustomWebView isVariable;

    protected Addon isVariable;

    private void isMethod(Context isParameter, UIManager isParameter, CustomWebView isParameter, Addon isParameter, Action isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
        isMethod(isNameExpr);
    }

    protected abstract void isMethod(Action isParameter);

    protected abstract void isMethod();

    public synchronized void isMethod(Context isParameter, UIManager isParameter, CustomWebView isParameter, Addon isParameter, Action isParameter) {
        isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr, isNameExpr);
        isMethod();
    }
}
