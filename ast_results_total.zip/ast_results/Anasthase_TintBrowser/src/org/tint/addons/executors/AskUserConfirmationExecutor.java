// isComment
package org.tint.addons.executors;

import org.tint.addons.framework.Action;
import org.tint.addons.framework.AskUserConfirmationAction;
import org.tint.controllers.Controller;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;

public class isClassOrIsInterface extends BaseActionExecutor {

    private AskUserConfirmationAction isVariable;

    @Override
    protected void isMethod(Action isParameter) {
        isNameExpr = (AskUserConfirmationAction) isNameExpr;
    }

    @Override
    protected void isMethod() {
        AlertDialog.Builder isVariable = new AlertDialog.Builder(isNameExpr);
        isNameExpr.isMethod(true);
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(isNameExpr.isMethod());
        isNameExpr.isMethod(isNameExpr.isMethod());
        isNameExpr.isMethod(true);
        isNameExpr.isMethod(isNameExpr.isMethod(), new OnClickListener() {

            @Override
            public void isMethod(DialogInterface isParameter, int isParameter) {
                isNameExpr.isMethod().isMethod().isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr.isMethod(), true);
            }
        });
        isNameExpr.isMethod(isNameExpr.isMethod(), new OnClickListener() {

            @Override
            public void isMethod(DialogInterface isParameter, int isParameter) {
                isNameExpr.isMethod().isMethod().isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr.isMethod(), true);
            }
        });
        isNameExpr.isMethod(new OnCancelListener() {

            @Override
            public void isMethod(DialogInterface isParameter) {
                isNameExpr.isMethod().isMethod().isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr.isMethod(), true);
            }
        });
        AlertDialog isVariable = isNameExpr.isMethod();
        isNameExpr.isMethod();
    }
}
