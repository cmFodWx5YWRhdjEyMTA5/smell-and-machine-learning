// isComment
package org.tint.addons.executors;

import org.tint.addons.framework.Action;
import org.tint.addons.framework.ShowToastAction;
import android.widget.Toast;

public class isClassOrIsInterface extends BaseActionExecutor {

    private ShowToastAction isVariable;

    @Override
    protected void isMethod(Action isParameter) {
        isNameExpr = (ShowToastAction) isNameExpr;
    }

    @Override
    protected void isMethod() {
        isNameExpr.isMethod(isNameExpr, isNameExpr.isMethod(), isNameExpr.isMethod()).isMethod();
    }
}
