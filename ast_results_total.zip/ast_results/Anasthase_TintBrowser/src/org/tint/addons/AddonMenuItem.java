// isComment
package org.tint.addons;

public class isClassOrIsInterface {

    private Addon isVariable;

    private String isVariable;

    public isConstructor(Addon isParameter, String isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
    }

    public Addon isMethod() {
        return isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }
}
