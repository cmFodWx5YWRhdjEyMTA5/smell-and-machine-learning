// isComment
package com.github.andlyticsproject.sync;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class isClassOrIsInterface extends BroadcastReceiver {

    private static final String isVariable = AccountsChangedReceiver.class.isMethod();

    @Override
    public void isMethod(Context isParameter, Intent isParameter) {
        isNameExpr.isMethod(isNameExpr, "isStringConstant");
        Intent isVariable = new Intent(isNameExpr, SyncDeveloperAccountsService.class);
        isNameExpr.isMethod(isNameExpr);
    }
}
