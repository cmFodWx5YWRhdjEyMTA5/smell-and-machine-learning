// isComment
package com.github.andlyticsproject.io;

import java.io.IOException;
import android.app.backup.BackupAgentHelper;
import android.app.backup.BackupDataInput;
import android.app.backup.BackupDataOutput;
import android.app.backup.SharedPreferencesBackupHelper;
import android.os.ParcelFileDescriptor;
import android.util.Log;

public class isClassOrIsInterface extends BackupAgentHelper {

    private static final String isVariable = AndlyticsBackupAgent.class.isMethod();

    private static final String isVariable = "isStringConstant";

    private static final String isVariable = "isStringConstant";

    private static final String isVariable = "isStringConstant";

    private static final String isVariable = "isStringConstant";

    private Object isVariable = new Object();

    @Override
    public void isMethod() {
        isMethod(isNameExpr, new SharedPreferencesBackupHelper(this, isNameExpr, isMethod() + "isStringConstant"));
        isMethod(isNameExpr, new DbBackupHelper(this, isNameExpr));
    }

    @Override
    public void isMethod(ParcelFileDescriptor isParameter, BackupDataOutput isParameter, ParcelFileDescriptor isParameter) throws IOException {
        isNameExpr.isMethod(isNameExpr, "isStringConstant");
        synchronized (isNameExpr) {
            super.isMethod(isNameExpr, isNameExpr, isNameExpr);
        }
    }

    @Override
    public void isMethod(BackupDataInput isParameter, int isParameter, ParcelFileDescriptor isParameter) throws IOException {
        isNameExpr.isMethod(isNameExpr, "isStringConstant" + isNameExpr);
        synchronized (isNameExpr) {
            isNameExpr.isMethod(isNameExpr, "isStringConstant");
            super.isMethod(isNameExpr, isNameExpr, isNameExpr);
        }
    }
}
