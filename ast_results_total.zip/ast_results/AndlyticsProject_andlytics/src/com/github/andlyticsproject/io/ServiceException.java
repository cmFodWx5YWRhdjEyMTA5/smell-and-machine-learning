// isComment
package com.github.andlyticsproject.io;

public class isClassOrIsInterface extends Exception {

    private static final long isVariable = isStringConstant;

    public isConstructor(Exception isParameter) {
        super(isNameExpr);
    }
}
