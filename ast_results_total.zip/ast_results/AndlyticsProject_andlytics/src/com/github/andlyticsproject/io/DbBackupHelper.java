// isComment
package com.github.andlyticsproject.io;

import android.app.backup.FileBackupHelper;
import android.content.Context;

public class isClassOrIsInterface extends FileBackupHelper {

    public isConstructor(Context isParameter, String isParameter) {
        super(isNameExpr, "isStringConstant" + isNameExpr);
    }
}
