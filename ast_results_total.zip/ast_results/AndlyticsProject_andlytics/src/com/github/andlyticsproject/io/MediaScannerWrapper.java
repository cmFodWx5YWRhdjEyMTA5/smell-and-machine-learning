// isComment
package com.github.andlyticsproject.io;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.MediaScannerConnection;

@SuppressLint("isStringConstant")
public class isClassOrIsInterface {

    private isConstructor() {
    }

    public static void isMethod(Context isParameter, String isParameter) {
        isNameExpr.isMethod(isNameExpr, new String[] { isNameExpr }, null, null);
    }
}
