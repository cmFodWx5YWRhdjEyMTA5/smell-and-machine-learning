// isComment
package com.github.andlyticsproject.db;

public class isClassOrIsInterface {

    public static final String isVariable = "isStringConstant";

    public static final String isVariable = "isStringConstant";

    public static final String isVariable = "isStringConstant";

    public static final String isVariable = "isStringConstant";

    public static final String isVariable = "isStringConstant";

    public static final String isVariable = "isStringConstant";

    public static final String isVariable = "isStringConstant" + isNameExpr + "isStringConstant" + isNameExpr + "isStringConstant" + isNameExpr + "isStringConstant" + isNameExpr + // isComment
    "isStringConstant";

    public static final String[] isVariable = { isNameExpr, isNameExpr, isNameExpr, isNameExpr };
}
