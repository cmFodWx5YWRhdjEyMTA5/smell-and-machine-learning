// isComment
package com.github.andlyticsproject.console;

public class isClassOrIsInterface extends DevConsoleException {

    public isConstructor(String isParameter) {
        super(isNameExpr);
    }
}
