// isComment
package com.github.andlyticsproject.console.v2;

import java.util.HashMap;
import java.util.Map;
import org.apache.http.impl.client.DefaultHttpClient;

public class isClassOrIsInterface {

    private Map<String, DevConsoleV2> isVariable = new HashMap<String, DevConsoleV2>();

    private static DevConsoleRegistry isVariable = new DevConsoleRegistry();

    private isConstructor() {
    }

    public static DevConsoleRegistry isMethod() {
        return isNameExpr;
    }

    public synchronized void isMethod(String isParameter, DevConsoleV2 isParameter) {
        isNameExpr.isMethod(isNameExpr, isNameExpr);
    }

    public synchronized DevConsoleV2 isMethod(String isParameter) {
        DevConsoleV2 isVariable = isNameExpr.isMethod(isNameExpr);
        if (isNameExpr == null) {
            DefaultHttpClient isVariable = isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
            isNameExpr = isNameExpr.isMethod(isNameExpr, isNameExpr);
            isNameExpr.isMethod(isNameExpr, isNameExpr);
        }
        return isNameExpr;
    }
}
