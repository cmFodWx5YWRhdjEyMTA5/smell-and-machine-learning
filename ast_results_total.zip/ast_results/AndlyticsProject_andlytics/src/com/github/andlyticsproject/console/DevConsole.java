// isComment
package com.github.andlyticsproject.console;

import java.util.List;
import android.app.Activity;
import com.github.andlyticsproject.model.AppInfo;
import com.github.andlyticsproject.model.Comment;

public interface isClassOrIsInterface {

    // isComment
    // isComment
    // isComment
    List<AppInfo> isMethod(Activity isParameter) throws DevConsoleException;

    List<Comment> isMethod(Activity isParameter, String isParameter, String isParameter, int isParameter, int isParameter, String isParameter) throws DevConsoleException;

    Comment isMethod(Activity isParameter, String isParameter, String isParameter, String isParameter, String isParameter);
}
