// isComment
package com.github.andlyticsproject.console.v2;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import com.github.andlyticsproject.AndlyticsApp;
import com.github.andlyticsproject.console.AuthenticationException;
import com.github.andlyticsproject.console.NetworkException;
import com.google.android.gms.auth.GoogleAuthException;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.auth.GooglePlayServicesAvailabilityException;
import com.google.android.gms.auth.UserRecoverableAuthException;
import com.google.android.gms.auth.UserRecoverableNotifiedException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.ExecutionContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class isClassOrIsInterface extends BaseAuthenticator {

    private static final String isVariable = OauthAccountManagerAuthenticator.class.isMethod();

    private static final String isVariable = "isStringConstant";

    private static final String isVariable = "isStringConstant";

    private static final String isVariable = "isStringConstant";

    private static final String isVariable = "isStringConstant";

    private static final int isVariable = isIntegerConstant;

    private static final boolean isVariable = true;

    private AccountManager isVariable;

    // isComment
    private String isVariable;

    private DefaultHttpClient isVariable;

    public isConstructor(String isParameter, DefaultHttpClient isParameter) {
        super(isNameExpr);
        this.isFieldAccessExpr = isNameExpr.isMethod(isNameExpr.isMethod());
        this.isFieldAccessExpr = isNameExpr;
    }

    @Override
    public SessionCredentials isMethod(Activity isParameter, boolean isParameter) throws AuthenticationException {
        return isMethod(isNameExpr, isNameExpr);
    }

    @Override
    public SessionCredentials isMethod(boolean isParameter) throws AuthenticationException {
        return isMethod(null, isNameExpr);
    }

    private SessionCredentials isMethod(Activity isParameter, boolean isParameter) throws AuthenticationException {
        try {
            Account[] isVariable = isNameExpr.isMethod("isStringConstant");
            Account isVariable = null;
            for (Account isVariable : isNameExpr) {
                if (isNameExpr.isFieldAccessExpr.isMethod(isNameExpr)) {
                    isNameExpr = isNameExpr;
                    break;
                }
            }
            if (isNameExpr == null) {
                throw new AuthenticationException(isNameExpr.isMethod("isStringConstant", isNameExpr));
            }
            if (isNameExpr && isNameExpr != null) {
                // isComment
                // isComment
                isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, isNameExpr);
            }
            String isVariable = null;
            if (isNameExpr == null) {
                // isComment
                try {
                    isNameExpr = isNameExpr.isMethod(isNameExpr.isMethod(), isNameExpr, isNameExpr, null);
                } catch (UserRecoverableNotifiedException isParameter) {
                    throw new AuthenticationException("isStringConstant");
                } catch (GoogleAuthException isParameter) {
                    // isComment
                    isNameExpr.isMethod(isNameExpr, "isStringConstant" + isNameExpr.isMethod(), isNameExpr);
                    throw new AuthenticationException("isStringConstant" + isNameExpr.isMethod());
                } catch (IOException isParameter) {
                    isNameExpr.isMethod(isNameExpr, "isStringConstant" + isNameExpr.isMethod());
                    throw new NetworkException(isNameExpr.isMethod());
                }
            } else {
                try {
                    isNameExpr = isNameExpr.isMethod(isNameExpr, isNameExpr, isNameExpr);
                } catch (GooglePlayServicesAvailabilityException isParameter) {
                    Dialog isVariable = isNameExpr.isMethod(isNameExpr.isMethod(), isNameExpr, isNameExpr);
                    isNameExpr.isMethod();
                    return null;
                } catch (UserRecoverableAuthException isParameter) {
                    Intent isVariable = isNameExpr.isMethod();
                    isNameExpr.isMethod(isNameExpr, isNameExpr);
                } catch (GoogleAuthException isParameter) {
                    // isComment
                    isNameExpr.isMethod(isNameExpr, "isStringConstant" + isNameExpr.isMethod(), isNameExpr);
                    throw new AuthenticationException("isStringConstant" + isNameExpr.isMethod());
                } catch (IOException isParameter) {
                    isNameExpr.isMethod(isNameExpr, "isStringConstant" + isNameExpr.isMethod());
                    throw new NetworkException(isNameExpr.isMethod());
                }
            }
            if (isNameExpr == null) {
                throw new AuthenticationException("isStringConstant");
            }
            if (isNameExpr) {
                isNameExpr.isMethod(isNameExpr, "isStringConstant" + isNameExpr);
            }
            HttpGet isVariable = new HttpGet(isNameExpr);
            isNameExpr.isMethod("isStringConstant", "isStringConstant" + isNameExpr);
            HttpResponse isVariable = isNameExpr.isMethod(isNameExpr);
            int isVariable = isNameExpr.isMethod().isMethod();
            if (isNameExpr == isNameExpr.isFieldAccessExpr) {
                throw new AuthenticationException("isStringConstant" + isNameExpr.isMethod());
            }
            String isVariable = isNameExpr.isMethod(isNameExpr.isMethod(), "isStringConstant");
            if (isNameExpr) {
                isNameExpr.isMethod(isNameExpr, "isStringConstant" + isNameExpr);
            }
            if (isNameExpr == null || "isStringConstant".isMethod(isNameExpr) || isNameExpr.isMethod("isStringConstant")) {
                throw new AuthenticationException("isStringConstant" + isNameExpr);
            }
            HttpPost isVariable = new HttpPost(isNameExpr);
            List<NameValuePair> isVariable = new ArrayList<NameValuePair>();
            isNameExpr.isMethod(new BasicNameValuePair("isStringConstant", isNameExpr));
            isNameExpr.isMethod(new BasicNameValuePair("isStringConstant", isNameExpr));
            isNameExpr.isMethod(new BasicNameValuePair("isStringConstant", "isStringConstant"));
            // isComment
            isNameExpr = isNameExpr.isMethod(isNameExpr).isMethod().isMethod("isStringConstant", "isStringConstant").isMethod("isStringConstant", isNameExpr).isMethod("isStringConstant", isNameExpr).isMethod().isMethod();
            if (isNameExpr) {
                isNameExpr.isMethod(isNameExpr, "isStringConstant" + isNameExpr);
            }
            UrlEncodedFormEntity isVariable = new UrlEncodedFormEntity(isNameExpr, "isStringConstant");
            isNameExpr.isMethod(isNameExpr);
            HttpContext isVariable = new BasicHttpContext();
            isNameExpr = isNameExpr.isMethod(isNameExpr, isNameExpr);
            isNameExpr = isNameExpr.isMethod().isMethod();
            if (isNameExpr == isNameExpr.isFieldAccessExpr) {
                throw new AuthenticationException("isStringConstant" + isNameExpr.isMethod());
            }
            if (isNameExpr != isNameExpr.isFieldAccessExpr) {
                throw new AuthenticationException("isStringConstant" + isNameExpr.isMethod());
            }
            String isVariable = isMethod(isNameExpr);
            if (isNameExpr) {
                isNameExpr.isMethod(isNameExpr, "isStringConstant" + isNameExpr);
            }
            HttpEntity isVariable = isNameExpr.isMethod();
            if (isNameExpr == null) {
                throw new AuthenticationException("isStringConstant");
            }
            String isVariable = isNameExpr.isMethod(isNameExpr, "isStringConstant");
            if (isNameExpr) {
                isNameExpr.isMethod(isNameExpr, "isStringConstant" + isNameExpr);
            }
            if (!isNameExpr.isMethod("isStringConstant")) {
                isMethod(isNameExpr, isNameExpr);
                throw new AuthenticationException("isStringConstant");
            }
            return isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr.isMethod().isMethod());
        } catch (IOException isParameter) {
            throw new NetworkException(isNameExpr);
        }
    }

    private static String isMethod(HttpContext isParameter) {
        HttpUriRequest isVariable = (HttpUriRequest) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
        HttpHost isVariable = (HttpHost) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
        String isVariable = (isNameExpr.isMethod().isMethod()) ? isNameExpr.isMethod().isMethod() : (isNameExpr.isMethod() + isNameExpr.isMethod());
        return isNameExpr;
    }
}
