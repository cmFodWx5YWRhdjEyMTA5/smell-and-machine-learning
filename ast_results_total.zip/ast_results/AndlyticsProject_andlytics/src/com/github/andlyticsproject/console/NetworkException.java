// isComment
package com.github.andlyticsproject.console;

public class isClassOrIsInterface extends DevConsoleException {

    /**
     * isComment
     */
    private static final long isVariable = isStringConstant;

    private int isVariable;

    public isConstructor(String isParameter) {
        super(isNameExpr);
    }

    public isConstructor(Throwable isParameter) {
        super(isNameExpr);
    }

    public isConstructor(String isParameter, Throwable isParameter) {
        super(isNameExpr, isNameExpr);
    }

    public isConstructor(Throwable isParameter, int isParameter) {
        super("isStringConstant" + isNameExpr, isNameExpr);
        this.isFieldAccessExpr = isNameExpr;
    }

    public int isMethod() {
        return isNameExpr;
    }
}
