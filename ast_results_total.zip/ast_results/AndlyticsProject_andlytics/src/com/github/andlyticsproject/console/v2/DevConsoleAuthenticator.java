// isComment
package com.github.andlyticsproject.console.v2;

import android.app.Activity;
import com.github.andlyticsproject.console.DevConsoleException;

public interface isClassOrIsInterface {

    String isMethod();

    // isComment
    // isComment
    // isComment
    SessionCredentials isMethod(Activity isParameter, boolean isParameter) throws DevConsoleException;

    // isComment
    SessionCredentials isMethod(boolean isParameter) throws DevConsoleException;
}
