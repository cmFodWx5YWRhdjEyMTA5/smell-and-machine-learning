// isComment
package com.github.andlyticsproject.console;

public class isClassOrIsInterface extends RuntimeException {

    /**
     * isComment
     */
    private static final long isVariable = isStringConstant;

    public isConstructor() {
        super();
    }

    public isConstructor(String isParameter) {
        super(isNameExpr);
    }

    public isConstructor(Throwable isParameter) {
        super(isNameExpr);
    }

    public isConstructor(String isParameter, Throwable isParameter) {
        super(isNameExpr, isNameExpr);
    }
}
