// isComment
package com.github.andlyticsproject.console;

public class isClassOrIsInterface extends DevConsoleException {

    /**
     * isComment
     */
    private static final long isVariable = -isStringConstant;

    public isConstructor(String isParameter) {
        super(isNameExpr);
    }

    public isConstructor(Throwable isParameter) {
        super(isNameExpr);
    }

    public isConstructor(String isParameter, Throwable isParameter) {
        super(isNameExpr, isNameExpr);
    }
}
