// isComment
package com.github.andlyticsproject.cache;

public class isClassOrIsInterface extends LRUBitmapCache {

    private static final long isVariable = isStringConstant;

    private static final int isVariable = isIntegerConstant;

    private static AppIconInMemoryCache isVariable;

    public isConstructor() {
        super(isNameExpr);
    }

    public static AppIconInMemoryCache isMethod() {
        if (isNameExpr == null) {
            isNameExpr = new AppIconInMemoryCache();
        }
        return isNameExpr;
    }
}
