// isComment
package com.github.andlyticsproject;

import com.github.andlyticsproject.model.Comment;

public interface isClassOrIsInterface {

    public void isMethod(Comment isParameter);

    public void isMethod();

    public void isMethod(String isParameter, String isParameter);
}
