// isComment
package com.github.andlyticsproject;

import java.util.List;
import android.os.AsyncTask;
import com.github.andlyticsproject.model.AppInfo;

public class isClassOrIsInterface {

    public interface isClassOrIsInterface {

        public void isMethod(List<AppInfo> isParameter);
    }

    public static class isClassOrIsInterface extends AsyncTask<String, Void, List<AppInfo>> {

        private List<AppInfo> isVariable = null;

        private LoadAppListTaskCompleteListener isVariable;

        public isConstructor(LoadAppListTaskCompleteListener isParameter) {
            isNameExpr = isNameExpr;
        }

        public void isMethod(LoadAppListTaskCompleteListener isParameter) {
            isNameExpr = isNameExpr;
        }

        public void isMethod() {
            isNameExpr = null;
        }

        public List<AppInfo> isMethod() {
            return isNameExpr;
        }

        @Override
        protected List<AppInfo> isMethod(String... isParameter) {
            return isNameExpr.isMethod().isMethod().isMethod(isNameExpr[isIntegerConstant]);
        }

        @Override
        protected void isMethod(List<AppInfo> isParameter) {
            isNameExpr = isNameExpr;
            if (isNameExpr != null) {
                isNameExpr.isMethod(isNameExpr);
            }
        }
    }
}
