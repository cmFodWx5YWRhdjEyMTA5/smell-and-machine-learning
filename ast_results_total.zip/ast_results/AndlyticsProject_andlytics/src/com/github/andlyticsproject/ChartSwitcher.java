// isComment
package com.github.andlyticsproject;

public interface isClassOrIsInterface {

    public void isMethod(int isParameter, int isParameter);
}
