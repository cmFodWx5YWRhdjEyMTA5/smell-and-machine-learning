// isComment
package com.github.andlyticsproject.admob;

public class isClassOrIsInterface extends AdmobException {

    private static final long isVariable = isStringConstant;

    public isConstructor(String isParameter) {
        super(isNameExpr);
    }

    public isConstructor(Exception isParameter) {
        super(isNameExpr);
    }

    public isConstructor(Exception isParameter, String isParameter) {
        super(isNameExpr, isNameExpr);
    }
}
