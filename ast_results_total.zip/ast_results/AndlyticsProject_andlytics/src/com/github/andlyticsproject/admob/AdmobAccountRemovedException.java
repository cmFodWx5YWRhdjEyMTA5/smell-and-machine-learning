// isComment
package com.github.andlyticsproject.admob;

public class isClassOrIsInterface extends AdmobException {

    private static final long isVariable = isStringConstant;

    private String isVariable;

    public isConstructor(String isParameter, String isParameter) {
        super(isNameExpr);
        this.isMethod(isNameExpr);
    }

    public void isMethod(String isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }
}
