// isComment
package com.github.andlyticsproject.admob;

// isComment
public class isClassOrIsInterface extends Exception {

    private static final long isVariable = isStringConstant;

    public isConstructor(String isParameter) {
        super(isNameExpr);
    }

    public isConstructor(Exception isParameter) {
        super(isNameExpr);
    }

    public isConstructor(String isParameter, Exception isParameter) {
        super(isNameExpr, isNameExpr);
    }
}
