// isComment
package com.github.andlyticsproject.model;

import java.util.Date;

public abstract class isClassOrIsInterface {

    protected Date isVariable;

    public Date isMethod() {
        return isNameExpr == null ? null : (Date) isNameExpr.isMethod();
    }

    public void isMethod(Date isParameter) {
        this.isFieldAccessExpr = isNameExpr == null ? null : (Date) isNameExpr.isMethod();
    }
}
