// isComment
package com.github.andlyticsproject.model;

public class isClassOrIsInterface {

    public Long isVariable;

    private String isVariable;

    private String isVariable;

    public Long isMethod() {
        return isNameExpr;
    }

    public void isMethod(Long isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }

    public void isMethod(String isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }

    public void isMethod(String isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }
}
