// isComment
package com.github.andlyticsproject.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class isClassOrIsInterface<T extends Statistic> {

    protected List<T> isVariable = new ArrayList<T>();

    protected T isVariable;

    public abstract void isMethod(T isParameter);

    public List<T> isMethod() {
        return isNameExpr.isMethod(isNameExpr);
    }

    public abstract void isMethod(int isParameter, boolean isParameter);

    public T isMethod() {
        return isNameExpr;
    }

    public abstract boolean isMethod();
}
