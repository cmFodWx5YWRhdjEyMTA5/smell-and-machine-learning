// isComment
package com.github.andlyticsproject.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class isClassOrIsInterface {

    private Long isVariable;

    private String isVariable;

    private String isVariable;

    private Date isVariable;

    private List<Link> isVariable = new ArrayList<Link>();

    public isConstructor(String isParameter, String isParameter, Date isParameter) {
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr == null ? null : (Date) isNameExpr.isMethod();
    }

    public isConstructor(String isParameter, String isParameter, Long isParameter) {
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr == null ? null : new Date(isNameExpr);
    }

    public isConstructor(String isParameter) {
        this(isNameExpr, null, (Date) null);
    }

    public Long isMethod() {
        return isNameExpr;
    }

    public void isMethod(Long isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }

    public void isMethod(String isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }

    public void isMethod(String isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    public Date isMethod() {
        return isNameExpr == null ? null : (Date) isNameExpr.isMethod();
    }

    public void isMethod(Date isParameter) {
        this.isFieldAccessExpr = isNameExpr == null ? null : (Date) isNameExpr.isMethod();
    }

    public List<Link> isMethod() {
        return isNameExpr.isMethod(isNameExpr);
    }

    public void isMethod(List<Link> isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    public void isMethod(Link isParameter) {
        isNameExpr.isMethod(isNameExpr);
    }
}
