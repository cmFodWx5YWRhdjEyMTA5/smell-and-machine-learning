// isComment
package com.github.andlyticsproject;

import com.github.andlyticsproject.model.Statistic;
import com.github.andlyticsproject.model.StatsSummary;

public interface isClassOrIsInterface<T extends Statistic> {

    public void isMethod(StatsSummary<T> isParameter);

    public String isMethod();

    public void isMethod(int isParameter, int isParameter);

    public int isMethod();
}
