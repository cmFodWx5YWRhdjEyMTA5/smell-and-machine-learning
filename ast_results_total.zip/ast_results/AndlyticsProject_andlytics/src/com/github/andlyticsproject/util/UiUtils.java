// isComment
package com.github.andlyticsproject.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.SwitchPreference;
import android.preference.TwoStatePreference;

@TargetApi(isNameExpr.isFieldAccessExpr.isFieldAccessExpr)
public class isClassOrIsInterface {

    private static final boolean isVariable = isNameExpr.isFieldAccessExpr.isFieldAccessExpr >= isNameExpr.isFieldAccessExpr.isFieldAccessExpr;

    private isConstructor() {
    }

    public static boolean isMethod(Preference isParameter) {
        if (isNameExpr.isFieldAccessExpr.isFieldAccessExpr >= isNameExpr.isFieldAccessExpr.isFieldAccessExpr) {
            return ((TwoStatePreference) isNameExpr).isMethod();
        }
        return ((CheckBoxPreference) isNameExpr).isMethod();
    }

    public static void isMethod(Preference isParameter, boolean isParameter) {
        if (isNameExpr.isFieldAccessExpr.isFieldAccessExpr >= isNameExpr.isFieldAccessExpr.isFieldAccessExpr) {
            ((TwoStatePreference) isNameExpr).isMethod(isNameExpr);
        } else {
            ((CheckBoxPreference) isNameExpr).isMethod(isNameExpr);
        }
    }

    public static Preference isMethod(Context isParameter) {
        return isNameExpr ? new SwitchPreference(isNameExpr) : new CheckBoxPreference(isNameExpr);
    }
}
