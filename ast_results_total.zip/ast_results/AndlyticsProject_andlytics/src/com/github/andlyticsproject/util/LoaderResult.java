// isComment
package com.github.andlyticsproject.util;

public class isClassOrIsInterface<T> {

    private T isVariable;

    private Exception isVariable;

    private isConstructor(T isParameter, Exception isParameter) {
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr;
    }

    public static <T> LoaderResult<T> isMethod(T isParameter) {
        return new LoaderResult<T>(isNameExpr, null);
    }

    public static <T> LoaderResult<T> isMethod(Exception isParameter) {
        return new LoaderResult<T>(null, isNameExpr);
    }

    public T isMethod() {
        return isNameExpr;
    }

    public Exception isMethod() {
        return isNameExpr;
    }

    public boolean isMethod() {
        return isNameExpr == null;
    }

    public boolean isMethod() {
        return !isMethod();
    }
}
