// isComment
package com.github.andlyticsproject;

// isComment
public interface isClassOrIsInterface {

    public void isMethod(Exception isParameter);

    public boolean isMethod();

    public void isMethod();

    public void isMethod();

    public boolean isMethod();

    public void isMethod(String isParameter);

    // isComment
    // isComment
    public String isMethod();

    public String isMethod();

    public String isMethod();
}
