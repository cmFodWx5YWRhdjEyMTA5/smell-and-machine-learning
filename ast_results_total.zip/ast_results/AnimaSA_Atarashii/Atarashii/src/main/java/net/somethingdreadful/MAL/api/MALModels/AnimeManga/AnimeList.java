// isComment
package net.somethingdreadful.MAL.api.MALModels.AnimeManga;

import net.somethingdreadful.MAL.api.BaseModels.AnimeManga.UserList;
import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface implements Serializable {

    @Setter
    @Getter
    private ArrayList<Anime> isVariable;

    @Setter
    @Getter
    private Statistics isVariable;

    public class isClassOrIsInterface implements Serializable {

        @Setter
        @Getter
        private float isVariable;
    }

    public static UserList isMethod(AnimeList isParameter) {
        UserList isVariable = new UserList();
        ArrayList<net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Anime> isVariable = new ArrayList<>();
        if (isNameExpr != null)
            isNameExpr = isMethod(isNameExpr.isMethod());
        isNameExpr.isMethod(isNameExpr);
        return isNameExpr;
    }

    public static ArrayList<net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Anime> isMethod(ArrayList<Anime> isParameter) {
        ArrayList<net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Anime> isVariable = new ArrayList<>();
        if (isNameExpr != null)
            for (Anime isVariable : isNameExpr) {
                isNameExpr.isMethod(isNameExpr.isMethod());
            }
        return isNameExpr;
    }
}
