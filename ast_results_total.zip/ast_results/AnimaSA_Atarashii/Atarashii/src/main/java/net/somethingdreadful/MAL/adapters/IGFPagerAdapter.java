// isComment
package net.somethingdreadful.MAL.adapters;

import android.app.Fragment;
import android.app.FragmentManager;
import android.support.v13.app.FragmentPagerAdapter;
import net.somethingdreadful.MAL.IGF;
import net.somethingdreadful.MAL.api.MALApi;

public class isClassOrIsInterface extends FragmentPagerAdapter {

    /**
     * isComment
     */
    public isConstructor(FragmentManager isParameter) {
        super(isNameExpr);
    }

    @Override
    public Fragment isMethod(int isParameter) {
        IGF isVariable = new IGF();
        isNameExpr.isMethod(isNameExpr == isIntegerConstant ? isNameExpr.isFieldAccessExpr.isFieldAccessExpr : isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        return isNameExpr;
    }

    @Override
    public int isMethod() {
        return isIntegerConstant;
    }

    @Override
    public CharSequence isMethod(int isParameter) {
        return isNameExpr.isMethod(isMethod(isNameExpr)).isMethod();
    }

    private MALApi.ListType isMethod(int isParameter) {
        switch(isNameExpr) {
            case isIntegerConstant:
                return isNameExpr.isFieldAccessExpr.isFieldAccessExpr;
            case isIntegerConstant:
                return isNameExpr.isFieldAccessExpr.isFieldAccessExpr;
            default:
                return null;
        }
    }
}
