// isComment
package net.somethingdreadful.MAL.adapters;

import android.app.Fragment;
import android.app.FragmentManager;
import android.support.v13.app.FragmentPagerAdapter;
import net.somethingdreadful.MAL.IGF;
import net.somethingdreadful.MAL.ProfileActivity;
import net.somethingdreadful.MAL.R;
import net.somethingdreadful.MAL.account.AccountService;
import net.somethingdreadful.MAL.api.APIHelper;
import net.somethingdreadful.MAL.api.MALApi;
import net.somethingdreadful.MAL.profile.ProfileDetailsAL;
import net.somethingdreadful.MAL.profile.ProfileDetailsMAL;
import net.somethingdreadful.MAL.profile.ProfileFriends;
import net.somethingdreadful.MAL.profile.ProfileHistory;

public class isClassOrIsInterface extends FragmentPagerAdapter {

    private final Fragments isVariable;

    public isConstructor(FragmentManager isParameter, ProfileActivity isParameter) {
        super(isNameExpr);
        isNameExpr = new Fragments(isNameExpr);
        if (isNameExpr.isMethod()) {
            isNameExpr.isMethod(new ProfileDetailsMAL(), isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
            isNameExpr.isMethod(new ProfileFriends(), isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
            if (isNameExpr.isMethod(isNameExpr)) {
                isNameExpr.isMethod(new ProfileHistory(), isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                isNameExpr.isMethod(new IGF().isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr), isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr));
                isNameExpr.isMethod(new IGF().isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr), isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr));
            }
        } else {
            isNameExpr.isMethod(new ProfileDetailsAL(), isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
            isNameExpr.isMethod(new ProfileFriends().isMethod(isIntegerConstant), isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
            if (isNameExpr.isMethod(isNameExpr)) {
                isNameExpr.isMethod(new ProfileFriends().isMethod(isIntegerConstant), isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                isNameExpr.isMethod(new ProfileHistory(), isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
                isNameExpr.isMethod(new IGF().isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr), isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr));
                isNameExpr.isMethod(new IGF().isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr), isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr));
            }
        }
    }

    @Override
    public Fragment isMethod(int isParameter) {
        return isNameExpr.isMethod(isNameExpr);
    }

    @Override
    public int isMethod() {
        return isNameExpr.isMethod();
    }

    @Override
    public String isMethod(int isParameter) {
        return isNameExpr.isMethod(isNameExpr);
    }
}
