// isComment
package net.somethingdreadful.MAL.api.MALModels.AnimeManga;

import com.google.gson.annotations.SerializedName;
import net.somethingdreadful.MAL.api.MALModels.RecordStub;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface implements Serializable {

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private HashMap<String, ArrayList<String>> isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private double isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private ArrayList<String> isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private ArrayList<String> isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private ArrayList<String> isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private ArrayList<RecordStub> isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    void isMethod(net.somethingdreadful.MAL.api.BaseModels.AnimeManga.GenericRecord isParameter) {
        isNameExpr.isMethod(isMethod());
        // isComment
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod().isMethod("isStringConstant"));
        isNameExpr.isMethod(isMethod().isMethod("isStringConstant"));
        isNameExpr.isMethod(isMethod().isMethod("isStringConstant"));
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isNameExpr.isMethod(isMethod()));
        isNameExpr.isMethod(isNameExpr.isMethod(isMethod()));
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(new Date());
    }

    private ArrayList<String> isMethod() {
        ArrayList<String> isVariable = new ArrayList<>();
        isNameExpr.isMethod(isMethod());
        return isNameExpr;
    }

    public String isMethod() {
        if (isNameExpr != null)
            return isNameExpr.isMethod("isStringConstant") ? isNameExpr.isMethod("isStringConstant", "isStringConstant") : isNameExpr.isMethod("isStringConstant", "isStringConstant");
        else
            return "isStringConstant";
    }
}
