// isComment
package net.somethingdreadful.MAL.api.BaseModels;

import net.somethingdreadful.MAL.api.MALModels.Profile;
import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface implements Serializable {

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable = isIntegerConstant;

    /**
     * isComment
     */
    @Setter
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable = isIntegerConstant;

    /**
     * isComment
     */
    @Setter
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private Forum isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private ArrayList<Forum> isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private Profile isVariable;
}
