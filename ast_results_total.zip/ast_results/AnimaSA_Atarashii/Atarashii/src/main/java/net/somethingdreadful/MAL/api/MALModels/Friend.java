// isComment
package net.somethingdreadful.MAL.api.MALModels;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface implements Serializable {

    /**
     * isComment
     */
    @Getter
    @Setter
    private String isVariable;

    /**
     * isComment
     */
    @Getter
    @Setter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Getter
    @Setter
    private Profile isVariable;

    private net.somethingdreadful.MAL.api.BaseModels.Profile isMethod() {
        net.somethingdreadful.MAL.api.BaseModels.Profile isVariable = new net.somethingdreadful.MAL.api.BaseModels.Profile();
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod().isMethod());
        isNameExpr.isMethod(isMethod().isMethod());
        return isNameExpr;
    }

    public static ArrayList<net.somethingdreadful.MAL.api.BaseModels.Profile> isMethod(ArrayList<Friend> isParameter) {
        ArrayList<net.somethingdreadful.MAL.api.BaseModels.Profile> isVariable = new ArrayList<>();
        for (Friend isVariable : isNameExpr) {
            isNameExpr.isMethod(isNameExpr.isMethod());
        }
        return isNameExpr;
    }
}
