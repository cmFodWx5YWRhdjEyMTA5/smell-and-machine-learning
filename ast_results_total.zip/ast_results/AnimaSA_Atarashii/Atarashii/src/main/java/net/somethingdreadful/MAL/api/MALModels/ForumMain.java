// isComment
package net.somethingdreadful.MAL.api.MALModels;

import com.google.gson.annotations.SerializedName;
import net.somethingdreadful.MAL.api.BaseModels.Forum;
import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface implements Serializable {

    /**
     * isComment
     */
    @Setter
    @Getter
    private ArrayList<Forum> isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private ArrayList<Forum> isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private ArrayList<Forum> isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private ArrayList<Forum> isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable;

    public ArrayList<Forum> isMethod() {
        ArrayList<Forum> isVariable = new ArrayList<>();
        if (isMethod() != null)
            isNameExpr.isMethod(isMethod());
        if (isMethod() != null)
            isNameExpr.isMethod(isMethod());
        if (isMethod() != null)
            isNameExpr.isMethod(isMethod());
        if (isMethod() != null) {
            isNameExpr.isMethod(isMethod());
            isNameExpr.isMethod(isIntegerConstant).isMethod(isMethod());
        }
        return isNameExpr;
    }
}
