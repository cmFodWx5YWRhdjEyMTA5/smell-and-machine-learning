// isComment
package net.somethingdreadful.MAL.api;

import net.somethingdreadful.MAL.api.ALModels.AnimeManga.Anime;
import net.somethingdreadful.MAL.api.ALModels.AnimeManga.Manga;
import net.somethingdreadful.MAL.api.ALModels.AnimeManga.Reviews;
import net.somethingdreadful.MAL.api.ALModels.AnimeManga.UserList;
import net.somethingdreadful.MAL.api.ALModels.Follow;
import net.somethingdreadful.MAL.api.ALModels.ForumAL;
import net.somethingdreadful.MAL.api.ALModels.ForumThread;
import net.somethingdreadful.MAL.api.ALModels.History;
import net.somethingdreadful.MAL.api.ALModels.OAuth;
import net.somethingdreadful.MAL.api.ALModels.Profile;
import java.util.ArrayList;
import java.util.Map;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

interface isClassOrIsInterface {

    @FormUrlEncoded
    @POST("isStringConstant")
    Call<OAuth> isMethod(@Field("isStringConstant") String isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") String isParameter);

    @GET("isStringConstant")
    Call<Profile> isMethod();

    @GET("isStringConstant")
    Call<Profile> isMethod(@Path("isStringConstant") String isParameter);

    @GET("isStringConstant")
    Call<ArrayList<History>> isMethod(@Path("isStringConstant") String isParameter, @Query("isStringConstant") int isParameter);

    @GET("isStringConstant")
    Call<UserList> isMethod(@Path("isStringConstant") String isParameter);

    @GET("isStringConstant")
    Call<UserList> isMethod(@Path("isStringConstant") String isParameter);

    @FormUrlEncoded
    @POST("isStringConstant")
    Call<OAuth> isMethod(@Field("isStringConstant") String isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") String isParameter);

    @GET("isStringConstant")
    Call<Anime> isMethod(@Path("isStringConstant") int isParameter);

    @GET("isStringConstant")
    Call<Manga> isMethod(@Path("isStringConstant") int isParameter);

    @GET("isStringConstant")
    Call<ArrayList<Anime>> isMethod(@Path("isStringConstant") String isParameter, @Query("isStringConstant") int isParameter);

    @GET("isStringConstant")
    Call<ArrayList<Manga>> isMethod(@Path("isStringConstant") String isParameter, @Query("isStringConstant") int isParameter);

    @GET("isStringConstant")
    Call<ArrayList<net.somethingdreadful.MAL.api.ALModels.AnimeManga.Anime>> isMethod(@QueryMap Map<String, String> isParameter);

    @GET("isStringConstant")
    Call<ArrayList<net.somethingdreadful.MAL.api.ALModels.AnimeManga.Manga>> isMethod(@QueryMap Map<String, String> isParameter);

    @GET("isStringConstant")
    Call<ArrayList<Follow>> isMethod(@Path("isStringConstant") String isParameter);

    @GET("isStringConstant")
    Call<ArrayList<Follow>> isMethod(@Path("isStringConstant") String isParameter);

    @FormUrlEncoded
    @POST("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") float isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @FormUrlEncoded
    @POST("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @FormUrlEncoded
    @POST("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @FormUrlEncoded
    @PUT("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") float isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @FormUrlEncoded
    @PUT("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @FormUrlEncoded
    @PUT("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @DELETE("isStringConstant")
    Call<ResponseBody> isMethod(@Path("isStringConstant") int isParameter);

    @DELETE("isStringConstant")
    Call<ResponseBody> isMethod(@Path("isStringConstant") int isParameter);

    @FormUrlEncoded
    @POST("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") float isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @FormUrlEncoded
    @POST("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @FormUrlEncoded
    @POST("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @FormUrlEncoded
    @PUT("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") float isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @FormUrlEncoded
    @PUT("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @FormUrlEncoded
    @PUT("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter, @Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    /*isComment*/
    @FormUrlEncoded
    @POST("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @FormUrlEncoded
    @PUT("isStringConstant")
    Call<ResponseBody> isMethod(@Field("isStringConstant") int isParameter, @Field("isStringConstant") String isParameter);

    @GET("isStringConstant")
    Call<ForumAL> isMethod(@Path("isStringConstant") String isParameter);

    @GET("isStringConstant")
    Call<ForumThread> isMethod(@Path("isStringConstant") int isParameter, @Query("isStringConstant") int isParameter);

    @GET("isStringConstant")
    Call<ForumAL> isMethod(@Query("isStringConstant") int isParameter, @Query("isStringConstant") int isParameter);

    @GET("isStringConstant")
    Call<ArrayList<Reviews>> isMethod(@Path("isStringConstant") int isParameter, @Query("isStringConstant") int isParameter);

    @GET("isStringConstant")
    Call<ArrayList<Reviews>> isMethod(@Path("isStringConstant") int isParameter, @Query("isStringConstant") int isParameter);
}
