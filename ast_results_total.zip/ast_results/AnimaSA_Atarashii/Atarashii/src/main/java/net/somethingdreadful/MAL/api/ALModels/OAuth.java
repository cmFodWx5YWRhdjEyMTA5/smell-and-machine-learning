// isComment
package net.somethingdreadful.MAL.api.ALModels;

import java.io.Serializable;

public class isClassOrIsInterface implements Serializable {

    public String isVariable;

    public String isVariable;

    public String isVariable;

    public String isVariable;

    public String isVariable;
}
