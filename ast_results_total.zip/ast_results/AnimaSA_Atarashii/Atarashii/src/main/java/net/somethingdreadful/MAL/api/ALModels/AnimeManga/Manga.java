// isComment
package net.somethingdreadful.MAL.api.ALModels.AnimeManga;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface extends GenericRecord implements Serializable {

    @Getter
    @Setter
    @SerializedName("isStringConstant")
    private String isVariable;

    @Getter
    @Setter
    @SerializedName("isStringConstant")
    private int isVariable;

    @Getter
    @Setter
    @SerializedName("isStringConstant")
    private int isVariable;

    public net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Manga isMethod() {
        net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Manga isVariable = new net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Manga();
        isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isMethod(true);
        isMethod(isNameExpr);
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isMethod(true);
        return isNameExpr;
    }

    public static ArrayList<net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Manga> isMethod(ArrayList<Manga> isParameter) {
        ArrayList<net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Manga> isVariable = new ArrayList<>();
        if (isNameExpr != null) {
            for (Manga isVariable : isNameExpr) {
                isNameExpr.isMethod(isNameExpr.isMethod());
            }
        }
        return isNameExpr;
    }
}
