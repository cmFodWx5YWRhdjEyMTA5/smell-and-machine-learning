// isComment
package net.somethingdreadful.MAL.api.MALModels;

import com.google.gson.annotations.SerializedName;
import net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Anime;
import net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Manga;
import net.somethingdreadful.MAL.api.BaseModels.Profile;
import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface implements Serializable {

    /**
     * isComment
     */
    @Getter
    @Setter
    private Series isVariable;

    /**
     * isComment
     */
    @Getter
    @Setter
    private String isVariable;

    /**
     * isComment
     */
    @Getter
    @Setter
    @SerializedName("isStringConstant")
    private String isVariable;

    class isClassOrIsInterface implements Serializable {

        /**
         * isComment
         */
        @Getter
        @Setter
        private int isVariable;

        /**
         * isComment
         */
        @Getter
        @Setter
        @SerializedName("isStringConstant")
        private int isVariable;

        /**
         * isComment
         */
        @Getter
        @Setter
        @SerializedName("isStringConstant")
        private int isVariable;

        /**
         * isComment
         */
        @Getter
        @Setter
        private String isVariable;

        /**
         * isComment
         */
        @Getter
        @Setter
        @SerializedName("isStringConstant")
        private String isVariable;
    }

    private net.somethingdreadful.MAL.api.BaseModels.History isMethod(String isParameter) {
        net.somethingdreadful.MAL.api.BaseModels.History isVariable = new net.somethingdreadful.MAL.api.BaseModels.History();
        if (isNameExpr.isMethod("isStringConstant")) {
            isNameExpr.isMethod(new Anime());
            isNameExpr.isMethod().isMethod(isMethod().isMethod());
            isNameExpr.isMethod(isNameExpr.isMethod(isMethod().isMethod()));
            isNameExpr.isMethod("isStringConstant");
            isNameExpr.isMethod().isMethod(isMethod().isMethod());
            isNameExpr.isMethod().isMethod("isStringConstant");
            isNameExpr.isMethod("isStringConstant");
        } else {
            isNameExpr.isMethod(new Manga());
            isNameExpr.isMethod().isMethod(isMethod().isMethod());
            isNameExpr.isMethod(isNameExpr.isMethod(isMethod().isMethod()));
            isNameExpr.isMethod("isStringConstant");
            isNameExpr.isMethod().isMethod(isMethod().isMethod());
            isNameExpr.isMethod().isMethod("isStringConstant");
            isNameExpr.isMethod("isStringConstant");
        }
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod("isStringConstant");
        // isComment
        ArrayList<Profile> isVariable = new ArrayList<>();
        Profile isVariable = new Profile();
        isNameExpr.isMethod(isNameExpr);
        isNameExpr.isMethod(isNameExpr);
        isNameExpr.isMethod(isNameExpr);
        return isNameExpr;
    }

    public static ArrayList<net.somethingdreadful.MAL.api.BaseModels.History> isMethod(ArrayList<History> isParameter, String isParameter) {
        ArrayList<net.somethingdreadful.MAL.api.BaseModels.History> isVariable = new ArrayList<>();
        for (History isVariable : isNameExpr) {
            isNameExpr.isMethod(isNameExpr.isMethod(isNameExpr));
        }
        return isNameExpr;
    }
}
