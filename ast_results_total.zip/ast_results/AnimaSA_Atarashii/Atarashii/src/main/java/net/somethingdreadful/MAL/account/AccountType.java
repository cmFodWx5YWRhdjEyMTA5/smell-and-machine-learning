// isComment
package net.somethingdreadful.MAL.account;

public enum AccountType {

    MyAnimeList, AniList
}
