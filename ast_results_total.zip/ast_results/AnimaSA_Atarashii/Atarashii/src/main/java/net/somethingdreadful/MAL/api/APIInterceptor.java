// isComment
package net.somethingdreadful.MAL.api;

import java.io.IOException;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

class isClassOrIsInterface implements Interceptor {

    private final String isVariable;

    private String isVariable = "isStringConstant";

    public isConstructor(String isParameter, String isParameter) {
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr;
    }

    @Override
    public Response isMethod(Interceptor.Chain isParameter) throws IOException {
        Request isVariable = isNameExpr.isMethod();
        Request isVariable = isNameExpr.isMethod().isMethod("isStringConstant").isMethod("isStringConstant", isNameExpr).isMethod("isStringConstant", isNameExpr).isMethod();
        return isNameExpr.isMethod(isNameExpr);
    }
}
