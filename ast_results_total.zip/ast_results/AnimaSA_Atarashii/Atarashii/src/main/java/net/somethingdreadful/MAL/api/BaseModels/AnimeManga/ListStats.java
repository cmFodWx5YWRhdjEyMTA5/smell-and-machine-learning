// isComment
package net.somethingdreadful.MAL.api.BaseModels.AnimeManga;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface implements Serializable {

    @Setter
    @SerializedName("isStringConstant")
    private int isVariable = isIntegerConstant;

    @Setter
    @SerializedName("isStringConstant")
    private int isVariable = isIntegerConstant;

    @Setter
    private int isVariable = isIntegerConstant;

    @Setter
    private int isVariable = isIntegerConstant;

    @Getter
    @Setter
    private int isVariable;

    @Getter
    @Setter
    @SerializedName("isStringConstant")
    private int isVariable;

    @Getter
    @Setter
    private int isVariable;

    public int isMethod() {
        return isNameExpr > isIntegerConstant ? isNameExpr : isNameExpr;
    }

    public int isMethod() {
        return isNameExpr > isIntegerConstant ? isNameExpr : isNameExpr;
    }
}
