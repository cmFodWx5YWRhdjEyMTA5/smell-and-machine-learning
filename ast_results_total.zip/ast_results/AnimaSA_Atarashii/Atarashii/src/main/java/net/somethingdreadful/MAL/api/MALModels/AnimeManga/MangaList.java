// isComment
package net.somethingdreadful.MAL.api.MALModels.AnimeManga;

import net.somethingdreadful.MAL.api.BaseModels.AnimeManga.UserList;
import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface implements Serializable {

    @Setter
    @Getter
    private ArrayList<Manga> isVariable;

    @Setter
    @Getter
    private Statistics isVariable;

    public class isClassOrIsInterface implements Serializable {

        @Setter
        @Getter
        private float isVariable;
    }

    public static UserList isMethod(MangaList isParameter) {
        UserList isVariable = new UserList();
        ArrayList<net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Manga> isVariable = new ArrayList<>();
        if (isNameExpr != null)
            isNameExpr = isMethod(isNameExpr.isMethod());
        isNameExpr.isMethod(isNameExpr);
        return isNameExpr;
    }

    public static ArrayList<net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Manga> isMethod(ArrayList<Manga> isParameter) {
        ArrayList<net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Manga> isVariable = new ArrayList<>();
        if (isNameExpr != null)
            for (Manga isVariable : isNameExpr) {
                isNameExpr.isMethod(isNameExpr.isMethod());
            }
        return isNameExpr;
    }
}
