// isComment
package net.somethingdreadful.MAL.api.MALModels.AnimeManga;

import com.google.gson.annotations.SerializedName;
import net.somethingdreadful.MAL.api.MALModels.RecordStub;
import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface extends GenericRecord implements Serializable {

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private ArrayList<RecordStub> isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private ArrayList<RecordStub> isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    private boolean isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    private boolean isMethod() {
        return isNameExpr;
    }

    public net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Manga isMethod() {
        net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Manga isVariable = new net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Manga();
        isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isMethod(true);
        isMethod(isNameExpr);
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod() ? isIntegerConstant : isIntegerConstant);
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isMethod(true);
        return isNameExpr;
    }
}
