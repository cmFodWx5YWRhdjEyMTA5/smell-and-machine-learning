// isComment
package net.somethingdreadful.MAL.api.MALModels.AnimeManga;

import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface implements Serializable {

    /**
     * isComment
     */
    @Getter
    @Setter
    private ArrayList<Anime> isVariable;

    /**
     * isComment
     */
    @Getter
    @Setter
    private ArrayList<Anime> isVariable;

    /**
     * isComment
     */
    @Getter
    @Setter
    private ArrayList<Anime> isVariable;

    /**
     * isComment
     */
    @Getter
    @Setter
    private ArrayList<Anime> isVariable;

    /**
     * isComment
     */
    @Getter
    @Setter
    private ArrayList<Anime> isVariable;

    /**
     * isComment
     */
    @Getter
    @Setter
    private ArrayList<Anime> isVariable;

    /**
     * isComment
     */
    @Getter
    @Setter
    private ArrayList<Anime> isVariable;

    public net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Schedule isMethod() {
        net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Schedule isVariable = new net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Schedule();
        isNameExpr.isMethod(isNameExpr.isMethod(isMethod()));
        isNameExpr.isMethod(isNameExpr.isMethod(isMethod()));
        isNameExpr.isMethod(isNameExpr.isMethod(isMethod()));
        isNameExpr.isMethod(isNameExpr.isMethod(isMethod()));
        isNameExpr.isMethod(isNameExpr.isMethod(isMethod()));
        isNameExpr.isMethod(isNameExpr.isMethod(isMethod()));
        isNameExpr.isMethod(isNameExpr.isMethod(isMethod()));
        return isNameExpr;
    }
}
