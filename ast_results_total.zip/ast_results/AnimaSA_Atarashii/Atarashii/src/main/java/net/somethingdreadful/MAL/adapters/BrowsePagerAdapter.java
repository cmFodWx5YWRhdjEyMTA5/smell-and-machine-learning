// isComment
package net.somethingdreadful.MAL.adapters;

import android.app.Fragment;
import android.app.FragmentManager;
import android.support.v13.app.FragmentPagerAdapter;
import net.somethingdreadful.MAL.BrowseActivity;
import net.somethingdreadful.MAL.BrowseFragmentAL;
import net.somethingdreadful.MAL.BrowseFragmentMAL;
import net.somethingdreadful.MAL.IGF;
import net.somethingdreadful.MAL.R;
import net.somethingdreadful.MAL.account.AccountService;
import net.somethingdreadful.MAL.api.MALApi;

public class isClassOrIsInterface extends FragmentPagerAdapter {

    private final Fragments isVariable;

    public isConstructor(FragmentManager isParameter, BrowseActivity isParameter) {
        super(isNameExpr);
        isNameExpr = new Fragments(isNameExpr);
        isNameExpr.isMethod(isNameExpr.isMethod() ? new BrowseFragmentMAL() : new BrowseFragmentAL(), isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isNameExpr.isMethod(new IGF().isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr), isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr));
    }

    public void isMethod(boolean isParameter) {
        isNameExpr.isMethod(isIntegerConstant, (isNameExpr ? isNameExpr.isFieldAccessExpr.isFieldAccessExpr : isNameExpr.isFieldAccessExpr.isFieldAccessExpr).isMethod());
        ((IGF) isNameExpr.isMethod(isIntegerConstant)).isMethod(isNameExpr ? isNameExpr.isFieldAccessExpr.isFieldAccessExpr : isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
        isMethod();
    }

    @Override
    public Fragment isMethod(int isParameter) {
        return isNameExpr.isMethod(isNameExpr);
    }

    @Override
    public int isMethod() {
        return isNameExpr.isMethod();
    }

    @Override
    public String isMethod(int isParameter) {
        return isNameExpr.isMethod(isNameExpr);
    }
}
