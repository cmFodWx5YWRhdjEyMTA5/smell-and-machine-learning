// isComment
package net.somethingdreadful.MAL.api.MALModels.AnimeManga;

import com.google.gson.annotations.SerializedName;
import net.somethingdreadful.MAL.api.MALModels.RecordStub;
import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;

public class isClassOrIsInterface extends GenericRecord implements Serializable {

    /**
     * isComment
     */
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private ArrayList<String> isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private ArrayList<String> isVariable;

    /**
     * isComment
     */
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Getter
    private ArrayList<String> isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private ArrayList<RecordStub> isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private ArrayList<RecordStub> isVariable;

    /**
     * isComment
     */
    @Getter
    private ArrayList<RecordStub> isVariable;

    /**
     * isComment
     */
    @Getter
    private ArrayList<RecordStub> isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private ArrayList<RecordStub> isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private RecordStub isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private ArrayList<RecordStub> isVariable;

    /**
     * isComment
     */
    @Getter
    private ArrayList<RecordStub> isVariable;

    /**
     * isComment
     */
    @Getter
    private ArrayList<RecordStub> isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private float isVariable;

    /**
     * isComment
     */
    private boolean isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    /**
     * isComment
     */
    @Getter
    @SerializedName("isStringConstant")
    private externalLinks isVariable;

    private class isClassOrIsInterface implements Serializable {

        @Getter
        @SerializedName("isStringConstant")
        private String isVariable;

        @Getter
        @SerializedName("isStringConstant")
        private String isVariable;

        @Getter
        @SerializedName("isStringConstant")
        private String isVariable;

        @Getter
        @SerializedName("isStringConstant")
        private String isVariable;
    }

    /**
     * isComment
     */
    private boolean isMethod() {
        return isNameExpr;
    }

    public net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Anime isMethod() {
        net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Anime isVariable = new net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Anime();
        isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isMethod(true);
        isMethod(isNameExpr);
        isNameExpr.isMethod(new net.somethingdreadful.MAL.api.ALModels.AnimeManga.Anime.Airing());
        isNameExpr.isMethod(new net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Anime.externalLinks());
        isNameExpr.isMethod().isMethod(isMethod() + isIntegerConstant);
        isNameExpr.isMethod().isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        if (isMethod() != null) {
            if (isMethod().isMethod() != null)
                isNameExpr.isMethod().isMethod(isMethod().isMethod());
            if (isMethod().isMethod() != null)
                isNameExpr.isMethod().isMethod(isMethod().isMethod());
            if (isMethod().isMethod() != null)
                isNameExpr.isMethod().isMethod(isMethod().isMethod());
            if (isMethod().isMethod() != null)
                isNameExpr.isMethod().isMethod(isMethod().isMethod());
        }
        isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isFieldAccessExpr.isMethod(true);
        return isNameExpr;
    }
}
