// isComment
package net.somethingdreadful.MAL;

import android.app.Activity;
import android.nfc.NfcAdapter;

public class isClassOrIsInterface {

    // isComment
    public static void isMethod(Activity isParameter) {
        NfcAdapter isVariable = isNameExpr.isMethod(isNameExpr);
        if (isNameExpr != null) {
            isNameExpr.isMethod(null, isNameExpr);
        }
    }
}
