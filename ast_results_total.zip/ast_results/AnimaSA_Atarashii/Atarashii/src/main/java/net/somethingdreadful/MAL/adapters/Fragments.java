// isComment
package net.somethingdreadful.MAL.adapters;

import android.app.Activity;
import android.app.Fragment;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;

class isClassOrIsInterface {

    private final ArrayList<FragmentHolder> isVariable = new ArrayList<>();

    private final Activity isVariable;

    isConstructor(Activity isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    /**
     * isComment
     */
    public void isMethod(Fragment isParameter, int isParameter) {
        isMethod(isNameExpr, isNameExpr.isMethod(isNameExpr));
    }

    /**
     * isComment
     */
    public void isMethod(Fragment isParameter, String isParameter) {
        isNameExpr.isMethod(new FragmentHolder(isNameExpr, isNameExpr));
    }

    /**
     * isComment
     */
    public int isMethod() {
        return isNameExpr.isMethod();
    }

    /**
     * isComment
     */
    public Fragment isMethod(int isParameter) {
        return isNameExpr.isMethod(isNameExpr).isMethod();
    }

    /**
     * isComment
     */
    public String isMethod(int isParameter) {
        return isNameExpr.isMethod(isNameExpr).isMethod();
    }

    /**
     * isComment
     */
    public void isMethod(int isParameter, String isParameter) {
        isNameExpr.isMethod(isNameExpr).isMethod(isNameExpr);
    }

    /**
     * isComment
     */
    public void isMethod() {
        isNameExpr.isMethod();
    }

    public class isClassOrIsInterface {

        @Getter
        @Setter
        private String isVariable;

        @Getter
        @Setter
        private Fragment isVariable;

        public isConstructor(Fragment isParameter, String isParameter) {
            this.isFieldAccessExpr = isNameExpr;
            this.isFieldAccessExpr = isNameExpr;
        }
    }
}
