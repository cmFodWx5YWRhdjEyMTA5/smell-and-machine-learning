// isComment
package net.somethingdreadful.MAL.api.ALModels;

import com.google.gson.annotations.SerializedName;
import net.somethingdreadful.MAL.api.BaseModels.Profile;
import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface implements Serializable {

    @Setter
    @Getter
    private int isVariable;

    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    private Profile isMethod() {
        net.somethingdreadful.MAL.api.BaseModels.Profile isVariable = new net.somethingdreadful.MAL.api.BaseModels.Profile();
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        return isNameExpr;
    }

    public static ArrayList<Profile> isMethod(ArrayList<Follow> isParameter) {
        ArrayList<Profile> isVariable = new ArrayList<>();
        if (isNameExpr != null) {
            for (Follow isVariable : isNameExpr) {
                isNameExpr.isMethod(isNameExpr.isMethod());
            }
        }
        return isNameExpr;
    }
}
