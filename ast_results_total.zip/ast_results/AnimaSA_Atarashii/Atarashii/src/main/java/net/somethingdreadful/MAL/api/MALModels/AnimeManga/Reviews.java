// isComment
package net.somethingdreadful.MAL.api.MALModels.AnimeManga;

import com.google.gson.annotations.SerializedName;
import net.somethingdreadful.MAL.api.BaseModels.Profile;
import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;

public class isClassOrIsInterface implements Serializable {

    /**
     * isComment
     */
    @Setter
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private int isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    @SerializedName("isStringConstant")
    private String isVariable;

    /**
     * isComment
     */
    @Setter
    @Getter
    private String isVariable;

    private net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Reviews isMethod() {
        net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Reviews isVariable = new net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Reviews();
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod());
        Profile isVariable = new Profile();
        isNameExpr.isMethod(isMethod());
        isNameExpr.isMethod(isMethod() == null ? "isStringConstant" : isMethod());
        isNameExpr.isMethod(isNameExpr);
        return isNameExpr;
    }

    public static ArrayList<net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Reviews> isMethod(ArrayList<Reviews> isParameter) {
        ArrayList<net.somethingdreadful.MAL.api.BaseModels.AnimeManga.Reviews> isVariable = new ArrayList<>();
        if (isNameExpr != null) {
            for (Reviews isVariable : isNameExpr) {
                isNameExpr.isMethod(isNameExpr.isMethod());
            }
        }
        return isNameExpr;
    }
}
