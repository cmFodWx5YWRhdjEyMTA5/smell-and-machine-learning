// isComment
package net.somethingdreadful.MAL;

import android.content.Context;
import android.util.Log;

public class isClassOrIsInterface {

    /**
     * isComment
     */
    public static void isMethod(Context isParameter) {
    }

    /**
     * isComment
     */
    public static void isMethod(String isParameter, String isParameter, Exception isParameter) {
        try {
            isNameExpr.isMethod();
        } catch (Exception isParameter) {
            isNameExpr.isMethod();
        }
    }

    /**
     * isComment
     */
    public static void isMethod(String isParameter, String isParameter) {
    }

    /**
     * isComment
     */
    public static void isMethod(String isParameter) {
    }

    /**
     * isComment
     */
    public static void isMethod(Exception isParameter) {
        isNameExpr.isMethod();
    }

    /**
     * isComment
     */
    public static void isMethod(int isParameter, String isParameter, String isParameter) {
        isNameExpr.isMethod(isNameExpr + "isStringConstant" + isNameExpr, isNameExpr);
    }
}
