// isComment
package com.achep.widget.jellyclock;

public final class isClassOrIsInterface {

    public static final boolean isVariable = true;
}
