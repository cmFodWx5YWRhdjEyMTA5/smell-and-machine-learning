// isComment
package com.achep.widget.jellyclock;

public final class isClassOrIsInterface {

    public static final class isClassOrIsInterface {
    }

    public static final class isClassOrIsInterface {

        public static final int isVariable = isIntegerConstant;

        public static final int isVariable = isIntegerConstant;
    }

    public static final class isClassOrIsInterface {

        public static final int isVariable = isIntegerConstant;

        public static final int isVariable = isIntegerConstant;

        public static final int isVariable = isIntegerConstant;

        public static final int isVariable = isIntegerConstant;

        public static final int isVariable = isIntegerConstant;

        public static final int isVariable = isIntegerConstant;

        public static final int isVariable = isIntegerConstant;

        public static final int isVariable = isIntegerConstant;

        public static final int isVariable = isIntegerConstant;

        public static final int isVariable = isIntegerConstant;
    }

    public static final class isClassOrIsInterface {

        public static final int isVariable = isIntegerConstant;

        public static final int isVariable = isIntegerConstant;

        public static final int isVariable = isIntegerConstant;
    }

    public static final class isClassOrIsInterface {

        public static final int isVariable = isIntegerConstant;
    }

    public static final class isClassOrIsInterface {

        public static final int isVariable = isIntegerConstant;
    }

    public static final class isClassOrIsInterface {

        public static final int isVariable = isIntegerConstant;
    }

    public static final class isClassOrIsInterface {

        public static final int isVariable = isIntegerConstant;
    }

    public static final class isClassOrIsInterface {

        public static final int isVariable = isIntegerConstant;
    }
}
