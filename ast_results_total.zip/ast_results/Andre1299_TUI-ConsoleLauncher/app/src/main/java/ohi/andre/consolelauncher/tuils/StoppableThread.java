// isComment
package ohi.andre.consolelauncher.tuils;

public class isClassOrIsInterface extends Thread {

    private volatile boolean isVariable = true;

    public isConstructor() {
        isNameExpr.isMethod(new UncaughtExceptionHandler() {

            @Override
            public void isMethod(Thread isParameter, Throwable isParameter) {
                isNameExpr.isMethod(isNameExpr);
                isNameExpr.isMethod(isNameExpr);
                isNameExpr.isMethod(isIntegerConstant);
            }
        });
    }

    @Override
    public void isMethod() {
        super.isMethod();
        synchronized (this) {
            isNameExpr = true;
        }
    }

    @Override
    public boolean isMethod() {
        boolean isVariable;
        synchronized (this) {
            isNameExpr = isNameExpr;
        }
        return isNameExpr || super.isMethod();
    }
}
