// isComment
package ohi.andre.consolelauncher.managers.flashlight;

import android.content.Context;

public abstract class isClassOrIsInterface {

    protected final Context isVariable;

    protected boolean isVariable;

    public isConstructor(Context isParameter) {
        this.isFieldAccessExpr = isNameExpr;
        isNameExpr = true;
    }

    public boolean isMethod() {
        return isNameExpr;
    }

    public void isMethod(boolean isParameter) {
        isNameExpr = isNameExpr;
    }
}
