// isComment
package ohi.andre.consolelauncher.managers.notifications.reply;

import ohi.andre.consolelauncher.tuils.Compare;

public class isClassOrIsInterface implements Compare.Stringable {

    public int isVariable;

    public String isVariable, isVariable;

    public isConstructor(int isParameter, String isParameter, String isParameter) {
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr;
    }

    @Override
    public boolean isMethod(Object isParameter) {
        return isNameExpr != null && isNameExpr instanceof BoundApp && isNameExpr == ((BoundApp) isNameExpr).isFieldAccessExpr;
    }

    @Override
    public String isMethod() {
        return isNameExpr;
    }
}
