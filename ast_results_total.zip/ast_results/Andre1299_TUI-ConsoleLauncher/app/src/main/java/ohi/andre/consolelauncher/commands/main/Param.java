// isComment
package ohi.andre.consolelauncher.commands.main;

import ohi.andre.consolelauncher.commands.ExecutePack;

public interface isClassOrIsInterface {

    int[] isMethod();

    String isMethod(ExecutePack isParameter);

    String isMethod();

    String isMethod(ExecutePack isParameter, int isParameter);

    String isMethod(ExecutePack isParameter, int isParameter);
}
