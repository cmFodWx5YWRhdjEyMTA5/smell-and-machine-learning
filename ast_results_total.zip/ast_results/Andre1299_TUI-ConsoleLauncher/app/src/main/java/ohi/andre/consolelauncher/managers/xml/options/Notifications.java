// isComment
package ohi.andre.consolelauncher.managers.xml.options;

import ohi.andre.consolelauncher.managers.notifications.NotificationManager;
import ohi.andre.consolelauncher.managers.xml.classes.XMLPrefsElement;
import ohi.andre.consolelauncher.managers.xml.classes.XMLPrefsSave;

public enum Notifications implements XMLPrefsSave {

    show_notifications {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    app_notification_enabled_default {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    default_notification_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    notification_format {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    click_notification {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    long_click_notification {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    notification_popup_exclude_app {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }
    }
    ,
    notification_popup_exclude_notification {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }
    }
    ,
    notification_popup_reply {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }
    }
    ;

    @Override
    public XMLPrefsElement isMethod() {
        return isNameExpr.isFieldAccessExpr;
    }

    @Override
    public String isMethod() {
        return isMethod();
    }

    @Override
    public boolean isMethod(String isParameter) {
        return isMethod().isMethod(isNameExpr);
    }

    @Override
    public String isMethod() {
        return isNameExpr.isFieldAccessExpr;
    }
}
