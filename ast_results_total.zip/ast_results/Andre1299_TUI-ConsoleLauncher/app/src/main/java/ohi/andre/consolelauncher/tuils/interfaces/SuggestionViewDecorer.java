// isComment
package ohi.andre.consolelauncher.tuils.interfaces;

import android.content.Context;
import android.widget.TextView;

/**
 * isComment
 */
public interface isClassOrIsInterface {

    TextView isMethod(Context isParameter);
}
