// isComment
package ohi.andre.consolelauncher.tuils;

import java.io.Serializable;
import java.util.Map;

public class isClassOrIsInterface<K, V> implements Map.Entry<K, V>, Serializable {

    private final K isVariable;

    private V isVariable;

    public isConstructor(K isParameter, V isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
    }

    public K isMethod() {
        return isNameExpr;
    }

    public V isMethod() {
        return isNameExpr;
    }

    public V isMethod(V isParameter) {
        V isVariable = isNameExpr;
        isNameExpr = isNameExpr;
        return isNameExpr;
    }

    @Override
    public String isMethod() {
        return isNameExpr + "isStringConstant" + isNameExpr;
    }
}
