// isComment
package ohi.andre.consolelauncher.commands.tuixt;

import android.content.Context;
import android.content.res.Resources;
import android.widget.EditText;
import java.io.File;
import ohi.andre.consolelauncher.commands.CommandGroup;
import ohi.andre.consolelauncher.commands.ExecutePack;

public class isClassOrIsInterface extends ExecutePack {

    public File isVariable;

    public EditText isVariable;

    public Resources isVariable;

    public isConstructor(CommandGroup isParameter, File isParameter, Context isParameter, EditText isParameter) {
        super(isNameExpr);
        this.isFieldAccessExpr = isNameExpr;
        isNameExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr.isMethod();
    }
}
