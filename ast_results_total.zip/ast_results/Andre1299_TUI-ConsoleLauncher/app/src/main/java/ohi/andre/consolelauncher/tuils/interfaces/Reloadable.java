// isComment
package ohi.andre.consolelauncher.tuils.interfaces;

public interface isClassOrIsInterface {

    public void isMethod();
}
