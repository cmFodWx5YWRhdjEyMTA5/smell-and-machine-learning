// isComment
package ohi.andre.consolelauncher.commands.specific;

import java.util.ArrayList;
import java.util.List;
import ohi.andre.consolelauncher.commands.CommandAbstraction;
import ohi.andre.consolelauncher.commands.ExecutePack;

public abstract class isClassOrIsInterface implements CommandAbstraction {

    public List<Object> isVariable = new ArrayList<>();

    public List<Object> isVariable = new ArrayList<>();

    public abstract String isMethod(ExecutePack isParameter);

    public abstract int isMethod();

    public abstract boolean isMethod();

    public void isMethod() {
        isNameExpr.isMethod();
        isNameExpr.isMethod();
    }
}
