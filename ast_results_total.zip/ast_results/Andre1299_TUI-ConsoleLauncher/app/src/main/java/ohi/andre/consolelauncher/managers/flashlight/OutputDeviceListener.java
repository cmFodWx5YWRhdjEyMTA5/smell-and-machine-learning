// isComment
package ohi.andre.consolelauncher.managers.flashlight;

public interface isClassOrIsInterface extends DeviceListener {

    void isMethod(boolean isParameter);
}
