// isComment
package ohi.andre.consolelauncher.managers.flashlight;

import android.content.Context;

public abstract class isClassOrIsInterface extends Torch {

    public static final String isVariable = isNameExpr.isFieldAccessExpr;

    public isConstructor(Context isParameter) {
        super(isNameExpr);
    }
}
