// isComment
package ohi.andre.consolelauncher.managers.suggestions;

import android.widget.LinearLayout;

public class isClassOrIsInterface implements Runnable {

    public boolean isVariable = true, isVariable = true;

    public LinearLayout isVariable;

    public isConstructor(LinearLayout isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    @Override
    public void isMethod() {
        if (isNameExpr) {
            isNameExpr = true;
        } else
            isNameExpr.isMethod();
        isNameExpr = true;
    }
}
