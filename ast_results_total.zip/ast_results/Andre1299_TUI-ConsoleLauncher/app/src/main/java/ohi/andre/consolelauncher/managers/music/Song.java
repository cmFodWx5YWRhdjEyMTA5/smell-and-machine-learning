// isComment
package ohi.andre.consolelauncher.managers.music;

import java.io.File;
import ohi.andre.consolelauncher.tuils.Compare;

public class isClassOrIsInterface implements Compare.Stringable {

    private long isVariable;

    private String isVariable, isVariable;

    public isConstructor(long isParameter, String isParameter) {
        isNameExpr = isNameExpr;
        isNameExpr = isNameExpr;
    }

    public isConstructor(File isParameter) {
        String isVariable = isNameExpr.isMethod();
        int isVariable = isNameExpr.isMethod("isStringConstant");
        isNameExpr = isNameExpr.isMethod(isIntegerConstant, isNameExpr);
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr.isMethod();
        this.isFieldAccessExpr = -isIntegerConstant;
    }

    public long isMethod() {
        return isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }

    public String isMethod() {
        return isNameExpr;
    }

    @Override
    public String isMethod() {
        return isNameExpr;
    }
}
