// isComment
package ohi.andre.consolelauncher.tuils.interfaces;

public interface isClassOrIsInterface {

    void isMethod(String isParameter);

    void isMethod(String isParameter);

    void isMethod();
}
