// isComment
package ohi.andre.consolelauncher.commands.tuixt.raw;

import android.app.Activity;
import ohi.andre.consolelauncher.R;
import ohi.andre.consolelauncher.commands.CommandAbstraction;
import ohi.andre.consolelauncher.commands.ExecutePack;
import ohi.andre.consolelauncher.commands.tuixt.TuixtPack;

public class isClassOrIsInterface implements CommandAbstraction {

    @Override
    public String isMethod(ExecutePack isParameter) throws Exception {
        TuixtPack isVariable = (TuixtPack) isNameExpr;
        ((Activity) isNameExpr.isFieldAccessExpr).isMethod();
        return null;
    }

    @Override
    public int[] isMethod() {
        return new int[isIntegerConstant];
    }

    @Override
    public int isMethod() {
        return isIntegerConstant;
    }

    @Override
    public int isMethod() {
        return isNameExpr.isFieldAccessExpr.isFieldAccessExpr;
    }

    @Override
    public String isMethod(ExecutePack isParameter, int isParameter) {
        return null;
    }

    @Override
    public String isMethod(ExecutePack isParameter, int isParameter) {
        return null;
    }
}
