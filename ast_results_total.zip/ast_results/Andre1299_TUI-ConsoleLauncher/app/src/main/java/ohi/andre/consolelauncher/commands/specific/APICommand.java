// isComment
package ohi.andre.consolelauncher.commands.specific;

public interface isClassOrIsInterface {

    boolean isMethod(int isParameter);
}
