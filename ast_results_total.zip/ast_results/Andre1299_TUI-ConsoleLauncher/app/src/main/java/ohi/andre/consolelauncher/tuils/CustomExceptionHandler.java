// isComment
package ohi.andre.consolelauncher.tuils;

public class isClassOrIsInterface implements Thread.UncaughtExceptionHandler {

    private Thread.UncaughtExceptionHandler isVariable;

    public isConstructor() {
        isNameExpr = isNameExpr.isMethod();
    }

    @Override
    public void isMethod(Thread isParameter, final Throwable isParameter) {
        isNameExpr.isMethod(isNameExpr);
        isNameExpr.isMethod(isNameExpr, isNameExpr);
    }
}
