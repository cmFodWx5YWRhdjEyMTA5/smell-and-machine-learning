// isComment
package ohi.andre.consolelauncher.tuils.interfaces;

public interface isClassOrIsInterface {

    void isMethod(float isParameter);

    void isMethod();

    void isMethod();
}
