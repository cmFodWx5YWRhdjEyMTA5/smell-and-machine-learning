// isComment
package ohi.andre.consolelauncher.managers.xml.options;

import ohi.andre.consolelauncher.managers.RssManager;
import ohi.andre.consolelauncher.managers.xml.classes.XMLPrefsElement;
import ohi.andre.consolelauncher.managers.xml.classes.XMLPrefsSave;

public enum Rss implements XMLPrefsSave {

    rss_default_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    rss_default_format {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    include_rss_default {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    rss_hidden_tags {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    rss_time_format {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    show_rss_download {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    rss_download_format {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    rss_download_message_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    click_rss {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ;

    // isComment
    // isComment
    // isComment
    // isComment
    // isComment
    // isComment
    @Override
    public XMLPrefsElement isMethod() {
        return isNameExpr.isFieldAccessExpr;
    }

    @Override
    public String isMethod() {
        return isMethod();
    }

    @Override
    public boolean isMethod(String isParameter) {
        return isMethod().isMethod(isNameExpr);
    }
}
