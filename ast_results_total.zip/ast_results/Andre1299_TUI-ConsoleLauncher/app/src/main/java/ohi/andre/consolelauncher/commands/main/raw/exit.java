// isComment
package ohi.andre.consolelauncher.commands.main.raw;

import ohi.andre.consolelauncher.R;
import ohi.andre.consolelauncher.commands.CommandAbstraction;
import ohi.andre.consolelauncher.commands.ExecutePack;
import ohi.andre.consolelauncher.tuils.Tuils;

public class isClassOrIsInterface implements CommandAbstraction {

    @Override
    public String isMethod(ExecutePack isParameter) throws Exception {
        isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
        return null;
    }

    @Override
    public int[] isMethod() {
        return new int[isIntegerConstant];
    }

    @Override
    public int isMethod() {
        return isIntegerConstant;
    }

    @Override
    public int isMethod() {
        return isNameExpr.isFieldAccessExpr.isFieldAccessExpr;
    }

    @Override
    public String isMethod(ExecutePack isParameter, int isParameter) {
        return null;
    }

    @Override
    public String isMethod(ExecutePack isParameter, int isParameter) {
        return null;
    }
}
