// isComment
package ohi.andre.consolelauncher.managers.suggestions;

import android.text.Editable;
import android.text.TextWatcher;

public class isClassOrIsInterface implements TextWatcher {

    SuggestionsManager isVariable;

    public isConstructor(SuggestionsManager isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    @Override
    public void isMethod(CharSequence isParameter, int isParameter, int isParameter, int isParameter) {
    }

    @Override
    public void isMethod(CharSequence isParameter, int isParameter, int isParameter, int isParameter) {
        isNameExpr.isMethod(isNameExpr.isMethod());
    }

    @Override
    public void isMethod(Editable isParameter) {
    }
}
