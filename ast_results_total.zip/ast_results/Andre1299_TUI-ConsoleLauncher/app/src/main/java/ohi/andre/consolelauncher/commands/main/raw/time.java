// isComment
package ohi.andre.consolelauncher.commands.main.raw;

import ohi.andre.consolelauncher.R;
import ohi.andre.consolelauncher.commands.CommandAbstraction;
import ohi.andre.consolelauncher.commands.ExecutePack;
import ohi.andre.consolelauncher.managers.TimeManager;

/**
 * isComment
 */
public class isClassOrIsInterface implements CommandAbstraction {

    @Override
    public String isMethod(ExecutePack isParameter) {
        int isVariable = isNameExpr.isMethod();
        return isNameExpr.isFieldAccessExpr.isMethod("isStringConstant" + isNameExpr).isMethod();
    }

    @Override
    public int isMethod() {
        return isIntegerConstant;
    }

    @Override
    public int[] isMethod() {
        return new int[] { isNameExpr.isFieldAccessExpr };
    }

    @Override
    public int isMethod() {
        return isNameExpr.isFieldAccessExpr.isFieldAccessExpr;
    }

    @Override
    public String isMethod(ExecutePack isParameter, int isParameter) {
        return isNameExpr.isFieldAccessExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
    }

    @Override
    public String isMethod(ExecutePack isParameter, int isParameter) {
        return isNameExpr.isFieldAccessExpr.isMethod("isStringConstant").isMethod();
    }
}
