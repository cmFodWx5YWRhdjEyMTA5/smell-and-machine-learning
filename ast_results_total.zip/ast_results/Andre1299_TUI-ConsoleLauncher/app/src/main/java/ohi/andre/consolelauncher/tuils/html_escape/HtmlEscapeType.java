// isComment
package ohi.andre.consolelauncher.tuils.html_escape;

/**
 * isComment
 */
public enum HtmlEscapeType {

    /**
     * isComment
     */
    HTML4_NAMED_REFERENCES_DEFAULT_TO_DECIMAL(true, true, true),
    /**
     * isComment
     */
    HTML4_NAMED_REFERENCES_DEFAULT_TO_HEXA(true, true, true),
    /**
     * isComment
     */
    HTML5_NAMED_REFERENCES_DEFAULT_TO_DECIMAL(true, true, true),
    /**
     * isComment
     */
    HTML5_NAMED_REFERENCES_DEFAULT_TO_HEXA(true, true, true),
    /**
     * isComment
     */
    DECIMAL_REFERENCES(true, true, true),
    /**
     * isComment
     */
    HEXADECIMAL_REFERENCES(true, true, true);

    private final boolean isVariable;

    private final boolean isVariable;

    private final boolean isVariable;

    isConstructor(final boolean isParameter, final boolean isParameter, final boolean isParameter) {
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr;
    }

    boolean isMethod() {
        return this.isFieldAccessExpr;
    }

    boolean isMethod() {
        return this.isFieldAccessExpr;
    }

    boolean isMethod() {
        return this.isFieldAccessExpr;
    }
}
