// isComment
package ohi.andre.consolelauncher.tuils.stuff;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

public class isClassOrIsInterface extends DeviceAdminReceiver {

    @Override
    public void isMethod(Context isParameter, Intent isParameter) {
    }

    @Override
    public CharSequence isMethod(Context isParameter, Intent isParameter) {
        return "isStringConstant";
    }

    @Override
    public void isMethod(Context isParameter, Intent isParameter) {
    }

    @Override
    public void isMethod(Context isParameter, Intent isParameter) {
    }

    @Override
    public void isMethod(Context isParameter, Intent isParameter) {
    }

    @Override
    public void isMethod(Context isParameter, Intent isParameter) {
    }
}
