// isComment
package ohi.andre.consolelauncher.managers.xml.classes;

public interface isClassOrIsInterface {

    String isVariable = "isStringConstant", isVariable = "isStringConstant", isVariable = "isStringConstant", isVariable = "isStringConstant", isVariable = "isStringConstant";

    String isMethod();

    String isMethod();

    String isMethod();

    String isMethod();

    XMLPrefsElement isMethod();

    boolean isMethod(String isParameter);
}
