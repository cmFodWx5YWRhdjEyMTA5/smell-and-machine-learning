// isComment
package ohi.andre.consolelauncher.managers.music;

import android.content.Context;
import android.widget.MediaController;

public class isClassOrIsInterface extends MediaController {

    public isConstructor(Context isParameter) {
        super(isNameExpr);
    }

    public void isMethod() {
    }
}
