// isComment
package ohi.andre.consolelauncher.commands;

import android.content.res.Resources;
import ohi.andre.consolelauncher.R;
import ohi.andre.consolelauncher.commands.main.Param;
import ohi.andre.consolelauncher.commands.specific.ParamCommand;
import ohi.andre.consolelauncher.tuils.Tuils;

public class isClassOrIsInterface {

    public CommandAbstraction isVariable;

    public Object[] isVariable;

    public int isVariable;

    public int isVariable = -isIntegerConstant;

    public String isMethod(Resources isParameter, ExecutePack isParameter) throws Exception {
        isNameExpr.isMethod(isNameExpr);
        if (isNameExpr instanceof ParamCommand) {
            if (isNameExpr == isIntegerConstant) {
                return isNameExpr.isMethod(isNameExpr, isNameExpr);
            }
            ParamCommand isVariable = (ParamCommand) isNameExpr;
            if (isNameExpr == null || isNameExpr.isFieldAccessExpr == isIntegerConstant) {
                return isNameExpr.isMethod(isNameExpr, isIntegerConstant);
            }
            Param isVariable = (Param) isNameExpr[isIntegerConstant];
            int[] isVariable = isNameExpr.isMethod();
            if (isNameExpr == null || isNameExpr[isIntegerConstant] instanceof String) {
                if (((String) isNameExpr[isIntegerConstant]).isMethod() == isIntegerConstant)
                    return isNameExpr.isMethod(isNameExpr, isIntegerConstant);
                else
                    return isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr) + isNameExpr.isFieldAccessExpr + isNameExpr[isIntegerConstant];
            }
            if (isNameExpr != -isIntegerConstant) {
                return isNameExpr.isMethod(isNameExpr, isNameExpr);
            }
            if (isNameExpr.isMethod() != null) {
                if (isNameExpr.isFieldAccessExpr > isNameExpr) {
                    return isNameExpr.isMethod(isNameExpr, isNameExpr);
                }
            } else {
                if (isNameExpr.isFieldAccessExpr + isIntegerConstant > isNameExpr) {
                    return isNameExpr.isMethod(isNameExpr, isNameExpr);
                }
            }
        } else if (isNameExpr != -isIntegerConstant) {
            return isNameExpr.isMethod(isNameExpr, isNameExpr);
        } else {
            int[] isVariable = isNameExpr.isMethod();
            if (isNameExpr < isNameExpr.isFieldAccessExpr || (isNameExpr == null && isNameExpr.isFieldAccessExpr > isIntegerConstant)) {
                return isNameExpr.isMethod(isNameExpr, isNameExpr);
            }
        }
        String isVariable = isNameExpr.isMethod(isNameExpr);
        isNameExpr.isMethod();
        return isNameExpr;
    }

    public int isMethod() {
        boolean isVariable = isNameExpr instanceof ParamCommand && isNameExpr != null && isNameExpr.isFieldAccessExpr >= isIntegerConstant;
        int[] isVariable;
        if (isNameExpr) {
            if (!(isNameExpr[isIntegerConstant] instanceof Param))
                isNameExpr = null;
            else
                isNameExpr = ((Param) isNameExpr[isIntegerConstant]).isMethod();
        } else {
            isNameExpr = isNameExpr.isMethod();
        }
        if (isNameExpr == null || isNameExpr.isFieldAccessExpr == isIntegerConstant) {
            return isIntegerConstant;
        }
        try {
            return isNameExpr[isNameExpr ? isNameExpr - isIntegerConstant : isNameExpr];
        } catch (ArrayIndexOutOfBoundsException isParameter) {
            return isIntegerConstant;
        }
    }
}
