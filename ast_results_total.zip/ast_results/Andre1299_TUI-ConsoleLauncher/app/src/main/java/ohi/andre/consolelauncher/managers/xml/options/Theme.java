// isComment
package ohi.andre.consolelauncher.managers.xml.options;

import ohi.andre.consolelauncher.managers.xml.XMLPrefsManager;
import ohi.andre.consolelauncher.managers.xml.classes.XMLPrefsElement;
import ohi.andre.consolelauncher.managers.xml.classes.XMLPrefsSave;

public enum Theme implements XMLPrefsSave {

    input_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    output_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    bg_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    device_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    battery_color_high {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    battery_color_medium {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    battery_color_low {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    time_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    storage_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    ram_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    network_info_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    toolbar_bg {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    toolbar_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    enter_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    cursor_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    overlay_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    alias_content_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    statusbar_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    navigationbar_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    app_installed_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    app_uninstalled_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    hint_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    mark_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    notes_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    notes_locked_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    link_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ;

    @Override
    public XMLPrefsElement isMethod() {
        return isNameExpr.isFieldAccessExpr.isFieldAccessExpr;
    }

    @Override
    public String isMethod() {
        return isMethod();
    }

    @Override
    public boolean isMethod(String isParameter) {
        return isMethod().isMethod(isNameExpr);
    }

    @Override
    public String isMethod() {
        return isNameExpr.isFieldAccessExpr;
    }
}
