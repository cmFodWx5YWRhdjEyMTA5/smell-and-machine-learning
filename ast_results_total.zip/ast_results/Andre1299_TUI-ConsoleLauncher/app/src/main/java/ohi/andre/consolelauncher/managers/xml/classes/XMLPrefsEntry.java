// isComment
package ohi.andre.consolelauncher.managers.xml.classes;

public class isClassOrIsInterface {

    public String isVariable, isVariable;

    public isConstructor(String isParameter, String isParameter) {
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr;
    }

    @Override
    public boolean isMethod(Object isParameter) {
        if (isNameExpr instanceof XMLPrefsEntry)
            return this == isNameExpr;
        else if (isNameExpr instanceof XMLPrefsSave)
            return this.isFieldAccessExpr.isMethod(((XMLPrefsSave) isNameExpr).isMethod());
        return isNameExpr.isMethod(isNameExpr);
    }

    @Override
    public String isMethod() {
        return isNameExpr + "isStringConstant" + isNameExpr;
    }
}
