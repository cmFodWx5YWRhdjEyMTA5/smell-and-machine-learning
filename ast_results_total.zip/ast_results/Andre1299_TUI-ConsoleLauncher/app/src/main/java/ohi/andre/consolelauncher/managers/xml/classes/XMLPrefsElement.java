// isComment
package ohi.andre.consolelauncher.managers.xml.classes;

public interface isClassOrIsInterface {

    XMLPrefsList isMethod();

    void isMethod(XMLPrefsSave isParameter, String isParameter);

    String[] isMethod();
}
