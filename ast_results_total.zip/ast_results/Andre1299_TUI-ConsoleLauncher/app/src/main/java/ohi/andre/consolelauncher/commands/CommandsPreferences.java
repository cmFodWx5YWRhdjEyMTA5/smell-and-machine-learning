// isComment
package ohi.andre.consolelauncher.commands;

import java.util.HashMap;
import ohi.andre.consolelauncher.managers.xml.XMLPrefsManager;
import ohi.andre.consolelauncher.managers.xml.classes.XMLPrefsSave;
import ohi.andre.consolelauncher.managers.xml.options.Cmd;

public class isClassOrIsInterface {

    public static final String isVariable = "isStringConstant";

    private HashMap<String, String> isVariable;

    public isConstructor() {
        isNameExpr = new HashMap<>();
        for (XMLPrefsSave isVariable : isNameExpr.isMethod()) {
            isNameExpr.isMethod(isNameExpr.isMethod(), isNameExpr.isMethod(isNameExpr));
        }
    }

    public String isMethod(String isParameter) {
        String isVariable = isNameExpr.isMethod(isNameExpr);
        if (isNameExpr == null)
            return isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr, isNameExpr);
        return isNameExpr;
    }

    public String isMethod(XMLPrefsSave isParameter) {
        String isVariable = isMethod(isNameExpr.isMethod());
        if (isNameExpr == null || isNameExpr.isMethod() == isIntegerConstant)
            isNameExpr = isNameExpr.isMethod();
        return isNameExpr;
    }

    public int isMethod(CommandAbstraction isParameter) {
        try {
            String isVariable = isMethod(isNameExpr.isMethod().isMethod() + isNameExpr);
            return isNameExpr.isMethod(isNameExpr);
        } catch (Exception isParameter) {
            return isNameExpr.isFieldAccessExpr;
        }
    }

    public int isMethod(CommandAbstraction isParameter) {
        int isVariable = isMethod(isNameExpr);
        if (isNameExpr == isNameExpr.isFieldAccessExpr)
            return isNameExpr.isMethod();
        return isNameExpr;
    }
}
