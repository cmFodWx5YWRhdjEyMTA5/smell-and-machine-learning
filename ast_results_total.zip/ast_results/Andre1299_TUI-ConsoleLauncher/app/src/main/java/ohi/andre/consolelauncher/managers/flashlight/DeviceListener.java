// isComment
package ohi.andre.consolelauncher.managers.flashlight;

public interface isClassOrIsInterface {

    void isMethod(String isParameter);
}
