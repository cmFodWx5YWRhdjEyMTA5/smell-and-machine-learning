// isComment
package ohi.andre.consolelauncher.tuils.html_escape;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

/**
 * isComment
 */
public final class isClassOrIsInterface {

    /**
     * isComment
     */
    public static String isMethod(final String isParameter) {
        return isMethod(isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static String isMethod(final String isParameter) {
        return isMethod(isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static String isMethod(final String isParameter) {
        return isMethod(isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static String isMethod(final String isParameter) {
        return isMethod(isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static String isMethod(final String isParameter, final HtmlEscapeType isParameter, final HtmlEscapeLevel isParameter) {
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        return isNameExpr.isMethod(isNameExpr, isNameExpr, isNameExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final String isParameter, final Writer isParameter) throws IOException {
        isMethod(isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final String isParameter, final Writer isParameter) throws IOException {
        isMethod(isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final String isParameter, final Writer isParameter) throws IOException {
        isMethod(isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final String isParameter, final Writer isParameter) throws IOException {
        isMethod(isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final String isParameter, final Writer isParameter, final HtmlEscapeType isParameter, final HtmlEscapeLevel isParameter) throws IOException {
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        isNameExpr.isMethod(new InternalStringReader(isNameExpr), isNameExpr, isNameExpr, isNameExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final Reader isParameter, final Writer isParameter) throws IOException {
        isMethod(isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final Reader isParameter, final Writer isParameter) throws IOException {
        isMethod(isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final Reader isParameter, final Writer isParameter) throws IOException {
        isMethod(isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final Reader isParameter, final Writer isParameter) throws IOException {
        isMethod(isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final Reader isParameter, final Writer isParameter, final HtmlEscapeType isParameter, final HtmlEscapeLevel isParameter) throws IOException {
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        isNameExpr.isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final char[] isParameter, final int isParameter, final int isParameter, final Writer isParameter) throws IOException {
        isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final char[] isParameter, final int isParameter, final int isParameter, final Writer isParameter) throws IOException {
        isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final char[] isParameter, final int isParameter, final int isParameter, final Writer isParameter) throws IOException {
        isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final char[] isParameter, final int isParameter, final int isParameter, final Writer isParameter) throws IOException {
        isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr, isNameExpr.isFieldAccessExpr, isNameExpr.isFieldAccessExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final char[] isParameter, final int isParameter, final int isParameter, final Writer isParameter, final HtmlEscapeType isParameter, final HtmlEscapeLevel isParameter) throws IOException {
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        final int isVariable = (isNameExpr == null ? isIntegerConstant : isNameExpr.isFieldAccessExpr);
        if (isNameExpr < isIntegerConstant || isNameExpr > isNameExpr) {
            throw new IllegalArgumentException("isStringConstant" + isNameExpr + "isStringConstant" + isNameExpr + "isStringConstant" + isNameExpr);
        }
        if (isNameExpr < isIntegerConstant || (isNameExpr + isNameExpr) > isNameExpr) {
            throw new IllegalArgumentException("isStringConstant" + isNameExpr + "isStringConstant" + isNameExpr + "isStringConstant" + isNameExpr);
        }
        isNameExpr.isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr, isNameExpr, isNameExpr);
    }

    /**
     * isComment
     */
    public static String isMethod(final String isParameter) {
        if (isNameExpr == null) {
            return null;
        }
        if (isNameExpr.isMethod('isStringConstant') < isIntegerConstant) {
            // isComment
            return isNameExpr;
        }
        return isNameExpr.isMethod(isNameExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final String isParameter, final Writer isParameter) throws IOException {
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        if (isNameExpr == null) {
            return;
        }
        if (isNameExpr.isMethod('isStringConstant') < isIntegerConstant) {
            // isComment
            isNameExpr.isMethod(isNameExpr);
            return;
        }
        isNameExpr.isMethod(new InternalStringReader(isNameExpr), isNameExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final Reader isParameter, final Writer isParameter) throws IOException {
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        isNameExpr.isMethod(isNameExpr, isNameExpr);
    }

    /**
     * isComment
     */
    public static void isMethod(final char[] isParameter, final int isParameter, final int isParameter, final Writer isParameter) throws IOException {
        if (isNameExpr == null) {
            throw new IllegalArgumentException("isStringConstant");
        }
        final int isVariable = (isNameExpr == null ? isIntegerConstant : isNameExpr.isFieldAccessExpr);
        if (isNameExpr < isIntegerConstant || isNameExpr > isNameExpr) {
            throw new IllegalArgumentException("isStringConstant" + isNameExpr + "isStringConstant" + isNameExpr + "isStringConstant" + isNameExpr);
        }
        if (isNameExpr < isIntegerConstant || (isNameExpr + isNameExpr) > isNameExpr) {
            throw new IllegalArgumentException("isStringConstant" + isNameExpr + "isStringConstant" + isNameExpr + "isStringConstant" + isNameExpr);
        }
        isNameExpr.isMethod(isNameExpr, isNameExpr, isNameExpr, isNameExpr);
    }

    private isConstructor() {
        super();
    }

    /*isComment*/
    private static final class isClassOrIsInterface extends Reader {

        private String isVariable;

        private int isVariable;

        private int isVariable = isIntegerConstant;

        public isConstructor(final String isParameter) {
            super();
            this.isFieldAccessExpr = isNameExpr;
            this.isFieldAccessExpr = isNameExpr.isMethod();
        }

        @Override
        public int isMethod() throws IOException {
            if (this.isFieldAccessExpr >= isNameExpr) {
                return -isIntegerConstant;
            }
            return this.isFieldAccessExpr.isMethod(this.isFieldAccessExpr++);
        }

        @Override
        public int isMethod(final char[] isParameter, final int isParameter, final int isParameter) throws IOException {
            if ((isNameExpr < isIntegerConstant) || (isNameExpr > isNameExpr.isFieldAccessExpr) || (isNameExpr < isIntegerConstant) || ((isNameExpr + isNameExpr) > isNameExpr.isFieldAccessExpr) || ((isNameExpr + isNameExpr) < isIntegerConstant)) {
                throw new IndexOutOfBoundsException();
            } else if (isNameExpr == isIntegerConstant) {
                return isIntegerConstant;
            }
            if (this.isFieldAccessExpr >= this.isFieldAccessExpr) {
                return -isIntegerConstant;
            }
            int isVariable = isNameExpr.isMethod(this.isFieldAccessExpr - this.isFieldAccessExpr, isNameExpr);
            this.isFieldAccessExpr.isMethod(this.isFieldAccessExpr, this.isFieldAccessExpr + isNameExpr, isNameExpr, isNameExpr);
            this.isFieldAccessExpr += isNameExpr;
            return isNameExpr;
        }

        @Override
        public void isMethod() throws IOException {
            // isComment
            this.isFieldAccessExpr = null;
        }
    }
}
