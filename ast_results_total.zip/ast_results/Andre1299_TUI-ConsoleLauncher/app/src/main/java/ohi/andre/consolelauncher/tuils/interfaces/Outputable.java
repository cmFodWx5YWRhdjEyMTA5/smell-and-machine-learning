// isComment
package ohi.andre.consolelauncher.tuils.interfaces;

/**
 * isComment
 */
public interface isClassOrIsInterface {

    void isMethod(CharSequence isParameter, int isParameter);

    void isMethod(int isParameter, CharSequence isParameter);

    void isMethod(CharSequence isParameter);

    void isMethod();
}
