// isComment
package ohi.andre.consolelauncher.managers.xml.options;

import ohi.andre.consolelauncher.managers.xml.XMLPrefsManager;
import ohi.andre.consolelauncher.managers.xml.classes.XMLPrefsElement;
import ohi.andre.consolelauncher.managers.xml.classes.XMLPrefsSave;

public enum Suggestions implements XMLPrefsSave {

    show_suggestions {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    transparent_suggestions {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    default_text_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    default_bg_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    apps_text_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    apps_bg_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    alias_text_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    alias_bg_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    cmd_text_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    cmd_bg_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    song_text_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    song_bg_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    contact_text_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    contact_bg_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    file_text_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    file_bg_color {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    suggest_alias_default {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    suggest_appgp_default {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    click_to_launch {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    suggestions_size {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    double_space_click_first_suggestion {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    noinput_suggestions_order {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    suggestions_order {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    noinput_min_command_priority {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    file_suggestions_minrate {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    app_suggestions_minrate {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    contact_suggestions_minrate {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ,
    song_suggestions_minrate {

        @Override
        public String isMethod() {
            return "isStringConstant";
        }

        @Override
        public String isMethod() {
            return isNameExpr.isFieldAccessExpr;
        }

        @Override
        public String isMethod() {
            return "isStringConstant";
        }
    }
    ;

    @Override
    public XMLPrefsElement isMethod() {
        return isNameExpr.isFieldAccessExpr.isFieldAccessExpr;
    }

    @Override
    public String isMethod() {
        return isMethod();
    }

    @Override
    public boolean isMethod(String isParameter) {
        return isMethod().isMethod(isNameExpr);
    }

    @Override
    public String isMethod() {
        return isNameExpr.isFieldAccessExpr;
    }
}
