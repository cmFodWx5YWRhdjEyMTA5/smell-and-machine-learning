// isComment
package ohi.andre.consolelauncher.managers.xml.classes;

import java.util.ArrayList;
import java.util.List;
import ohi.andre.consolelauncher.tuils.Tuils;

public class isClassOrIsInterface {

    public List<XMLPrefsEntry> isVariable = new ArrayList<>();

    public void isMethod(XMLPrefsEntry isParameter) {
        isNameExpr.isMethod(isNameExpr);
    }

    public void isMethod(String isParameter, String isParameter) {
        isNameExpr.isMethod(new XMLPrefsEntry(isNameExpr, isNameExpr));
    }

    public XMLPrefsEntry isMethod(Object isParameter) {
        if (isNameExpr instanceof Integer)
            return isMethod((Integer) isNameExpr);
        for (XMLPrefsEntry isVariable : isNameExpr) if (isNameExpr.isMethod(isNameExpr))
            return isNameExpr;
        return null;
    }

    public XMLPrefsEntry isMethod(int isParameter) {
        return isNameExpr.isMethod(isNameExpr);
    }

    public int isMethod() {
        return isNameExpr.isMethod();
    }

    public List<String> isMethod() {
        List<String> isVariable = new ArrayList<>();
        for (XMLPrefsEntry isVariable : isNameExpr) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr + "isStringConstant" + isNameExpr.isFieldAccessExpr);
        return isNameExpr;
    }

    @Override
    public String isMethod() {
        StringBuilder isVariable = new StringBuilder();
        for (XMLPrefsEntry isVariable : isNameExpr) {
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr).isMethod("isStringConstant").isMethod(isNameExpr.isFieldAccessExpr).isMethod(isNameExpr.isFieldAccessExpr);
        }
        return isNameExpr.isMethod().isMethod();
    }
}
