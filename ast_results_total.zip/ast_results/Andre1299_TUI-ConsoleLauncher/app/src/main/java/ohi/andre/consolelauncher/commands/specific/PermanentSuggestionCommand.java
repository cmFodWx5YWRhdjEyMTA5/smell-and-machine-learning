// isComment
package ohi.andre.consolelauncher.commands.specific;

import ohi.andre.consolelauncher.commands.CommandAbstraction;

public abstract class isClassOrIsInterface implements CommandAbstraction {

    public abstract String[] isMethod();
}
