// isComment
package ohi.andre.consolelauncher.commands.main.raw;

import android.media.AudioManager;
import android.media.ToneGenerator;
import ohi.andre.consolelauncher.R;
import ohi.andre.consolelauncher.commands.CommandAbstraction;
import ohi.andre.consolelauncher.commands.ExecutePack;
import ohi.andre.consolelauncher.commands.main.MainPack;

public class isClassOrIsInterface implements CommandAbstraction {

    @Override
    public String isMethod(ExecutePack isParameter) throws Exception {
        try {
            ToneGenerator isVariable = new ToneGenerator(isNameExpr.isFieldAccessExpr, isIntegerConstant);
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr, isIntegerConstant);
        } catch (Exception isParameter) {
            return isNameExpr.isMethod();
        }
        return null;
    }

    @Override
    public int[] isMethod() {
        return new int[isIntegerConstant];
    }

    @Override
    public int isMethod() {
        return isIntegerConstant;
    }

    @Override
    public int isMethod() {
        return isNameExpr.isFieldAccessExpr.isFieldAccessExpr;
    }

    @Override
    public String isMethod(ExecutePack isParameter, int isParameter) {
        return null;
    }

    @Override
    public String isMethod(ExecutePack isParameter, int isParameter) {
        return ((MainPack) isNameExpr).isFieldAccessExpr.isMethod(isMethod());
    }
}
