// isComment
package ohi.andre.consolelauncher.tuils.stuff;

import android.app.Activity;

public class isClassOrIsInterface extends Activity {
}
