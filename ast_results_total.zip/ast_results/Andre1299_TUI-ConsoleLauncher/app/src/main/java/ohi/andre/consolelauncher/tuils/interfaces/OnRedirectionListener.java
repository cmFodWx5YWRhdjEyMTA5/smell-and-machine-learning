// isComment
package ohi.andre.consolelauncher.tuils.interfaces;

import ohi.andre.consolelauncher.commands.specific.RedirectCommand;

public interface isClassOrIsInterface {

    void isMethod(RedirectCommand isParameter);

    void isMethod(RedirectCommand isParameter);
}
