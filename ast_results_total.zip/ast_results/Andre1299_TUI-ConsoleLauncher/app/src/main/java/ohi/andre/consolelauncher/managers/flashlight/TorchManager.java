// isComment
package ohi.andre.consolelauncher.managers.flashlight;

import android.content.Context;
import android.os.Build;

public class isClassOrIsInterface {

    private static TorchManager isVariable;

    private final String isVariable;

    private Torch isVariable;

    private String isVariable;

    private isConstructor() {
        this.isFieldAccessExpr = (isNameExpr.isFieldAccessExpr.isFieldAccessExpr >= isNameExpr.isFieldAccessExpr.isFieldAccessExpr) ? isNameExpr.isFieldAccessExpr : isNameExpr.isFieldAccessExpr;
        this.isMethod(isNameExpr.isFieldAccessExpr);
    }

    public static TorchManager isMethod() {
        if (isNameExpr == null) {
            isNameExpr = new TorchManager();
        }
        return isNameExpr;
    }

    public boolean isMethod() {
        return this.isFieldAccessExpr != null;
    }

    public void isMethod(String isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    public void isMethod(Context isParameter) {
        if (this.isFieldAccessExpr == null) {
            if (this.isFieldAccessExpr.isMethod(isNameExpr.isFieldAccessExpr)) {
                if (this.isFieldAccessExpr.isMethod(isNameExpr.isFieldAccessExpr)) {
                    this.isFieldAccessExpr = new Flashlight1(isNameExpr);
                } else if (this.isFieldAccessExpr.isMethod(isNameExpr.isFieldAccessExpr)) {
                    this.isFieldAccessExpr = new Flashlight2(isNameExpr);
                }
            }
        }
        this.isFieldAccessExpr.isMethod(true);
        this.isFieldAccessExpr.isMethod(true);
    }

    public void isMethod() {
        if (this.isFieldAccessExpr != null) {
            this.isFieldAccessExpr.isMethod(true);
            this.isFieldAccessExpr = null;
        }
    }

    public void isMethod(Context isParameter) {
        if (this.isFieldAccessExpr == null) {
            this.isMethod(isNameExpr);
        } else {
            if (this.isFieldAccessExpr.isMethod()) {
                this.isMethod();
            } else {
                this.isMethod(isNameExpr);
            }
        }
    }
}
