// isComment
package ohi.andre.consolelauncher.tuils.html_escape;

/**
 * isComment
 */
public enum HtmlEscapeLevel {

    /**
     * isComment
     */
    LEVEL_0_ONLY_MARKUP_SIGNIFICANT_EXCEPT_APOS(isIntegerConstant),
    /**
     * isComment
     */
    LEVEL_1_ONLY_MARKUP_SIGNIFICANT(isIntegerConstant),
    /**
     * isComment
     */
    LEVEL_2_ALL_NON_ASCII_PLUS_MARKUP_SIGNIFICANT(isIntegerConstant),
    /**
     * isComment
     */
    LEVEL_3_ALL_NON_ALPHANUMERIC(isIntegerConstant),
    /**
     * isComment
     */
    LEVEL_4_ALL_CHARACTERS(isIntegerConstant);

    private final int isVariable;

    /**
     * isComment
     */
    public static HtmlEscapeLevel isMethod(final int isParameter) {
        switch(isNameExpr) {
            case isIntegerConstant:
                return isNameExpr;
            case isIntegerConstant:
                return isNameExpr;
            case isIntegerConstant:
                return isNameExpr;
            case isIntegerConstant:
                return isNameExpr;
            case isIntegerConstant:
                return isNameExpr;
            default:
                throw new IllegalArgumentException("isStringConstant" + isNameExpr);
        }
    }

    isConstructor(final int isParameter) {
        this.isFieldAccessExpr = isNameExpr;
    }

    /**
     * isComment
     */
    public int isMethod() {
        return this.isFieldAccessExpr;
    }
}
