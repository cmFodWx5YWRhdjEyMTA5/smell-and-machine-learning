// isComment
package ohi.andre.consolelauncher.tuils.stuff;

import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;

public class isClassOrIsInterface {

    public static OnGestureListener isVariable = new OnGestureListener() {

        @Override
        public boolean isMethod(MotionEvent isParameter) {
            return true;
        }

        @Override
        public void isMethod(MotionEvent isParameter) {
        }

        @Override
        public boolean isMethod(MotionEvent isParameter) {
            return true;
        }

        @Override
        public boolean isMethod(MotionEvent isParameter, MotionEvent isParameter, float isParameter, float isParameter) {
            return true;
        }

        @Override
        public void isMethod(MotionEvent isParameter) {
        }

        @Override
        public boolean isMethod(MotionEvent isParameter, MotionEvent isParameter, float isParameter, float isParameter) {
            return true;
        }
    };
}
