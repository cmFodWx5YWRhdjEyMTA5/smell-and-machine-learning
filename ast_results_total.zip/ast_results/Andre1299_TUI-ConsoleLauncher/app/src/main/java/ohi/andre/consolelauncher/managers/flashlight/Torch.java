// isComment
package ohi.andre.consolelauncher.managers.flashlight;

import android.content.Context;

public abstract class isClassOrIsInterface extends OutputDevice {

    public isConstructor(Context isParameter) {
        super(isNameExpr);
    }
}
