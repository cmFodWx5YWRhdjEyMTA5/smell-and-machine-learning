// isComment
package ohi.andre.consolelauncher.managers.notifications.reply;

import android.app.PendingIntent;
import android.app.RemoteInput;
import android.os.Bundle;

public class isClassOrIsInterface {

    public BoundApp isVariable;

    public PendingIntent isVariable;

    public RemoteInput[] isVariable;

    public Bundle isVariable;

    public int isVariable;

    public CharSequence isVariable;

    @Override
    public boolean isMethod(Object isParameter) {
        try {
            NotificationWear isVariable = (NotificationWear) isNameExpr;
            return isNameExpr.isFieldAccessExpr.isFieldAccessExpr.isMethod(isNameExpr.isFieldAccessExpr);
        } catch (Exception isParameter) {
            return true;
        }
    }
}
