// isComment
package ohi.andre.consolelauncher.commands.main.raw;

import ohi.andre.consolelauncher.R;
import ohi.andre.consolelauncher.commands.CommandAbstraction;
import ohi.andre.consolelauncher.commands.ExecutePack;
import ohi.andre.consolelauncher.commands.main.MainPack;

public class isClassOrIsInterface implements CommandAbstraction {

    @Override
    public String isMethod(ExecutePack isParameter) {
        MainPack isVariable = (MainPack) isNameExpr;
        isNameExpr.isFieldAccessExpr.isMethod();
        isNameExpr.isFieldAccessExpr.isMethod();
        if (isNameExpr.isFieldAccessExpr != null)
            isNameExpr.isFieldAccessExpr.isMethod();
        isNameExpr.isFieldAccessExpr.isMethod(isNameExpr.isFieldAccessExpr);
        isNameExpr.isFieldAccessExpr.isMethod();
        return isNameExpr.isFieldAccessExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
    }

    @Override
    public int isMethod() {
        return isNameExpr.isFieldAccessExpr.isFieldAccessExpr;
    }

    @Override
    public int[] isMethod() {
        return new int[isIntegerConstant];
    }

    @Override
    public int isMethod() {
        return isIntegerConstant;
    }

    @Override
    public String isMethod(ExecutePack isParameter, int isParameter) {
        return null;
    }

    @Override
    public String isMethod(ExecutePack isParameter, int isParameter) {
        return null;
    }
}
