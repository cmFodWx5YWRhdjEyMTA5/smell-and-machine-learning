// isComment
package org.tint.adblock;

import org.tint.adblock.R;
import org.tint.addons.framework.IAddon;
import android.app.Service;
import android.os.RemoteException;

public abstract class isClassOrIsInterface extends IAddon.Stub {

    protected Service isVariable;

    public isConstructor(Service isParameter) {
        super();
        isNameExpr = isNameExpr;
    }

    @Override
    public String isMethod() throws RemoteException {
        return isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
    }

    @Override
    public String isMethod() throws RemoteException {
        return isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
    }

    @Override
    public String isMethod() throws RemoteException {
        return isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
    }

    @Override
    public String isMethod() throws RemoteException {
        return isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
    }
}
