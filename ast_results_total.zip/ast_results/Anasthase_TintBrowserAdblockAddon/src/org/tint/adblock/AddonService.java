// isComment
package org.tint.adblock;

import org.tint.addons.framework.IAddon;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class isClassOrIsInterface extends Service {

    private IAddon.Stub isVariable = new Addon(this);

    @Override
    public void isMethod(Intent isParameter, int isParameter) {
        super.isMethod(isNameExpr, isNameExpr);
    }

    @Override
    public void isMethod() {
        super.isMethod();
    }

    @Override
    public IBinder isMethod(Intent isParameter) {
        return isNameExpr;
    }
}
