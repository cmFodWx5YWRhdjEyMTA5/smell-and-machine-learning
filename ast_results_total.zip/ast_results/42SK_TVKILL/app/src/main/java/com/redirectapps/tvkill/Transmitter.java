// isComment
package com.redirectapps.tvkill;

import android.content.Context;
import android.hardware.ConsumerIrManager;

public class isClassOrIsInterface {

    int isVariable;

    int[] isVariable;

    isConstructor(int isParameter, int[] isParameter) {
        this.isFieldAccessExpr = isNameExpr;
        this.isFieldAccessExpr = isNameExpr;
    }

    public void isMethod(Context isParameter) {
        ConsumerIrManager isVariable = (ConsumerIrManager) isNameExpr.isMethod(isNameExpr.isFieldAccessExpr);
        isNameExpr.isMethod(isNameExpr, isNameExpr);
    }
}
