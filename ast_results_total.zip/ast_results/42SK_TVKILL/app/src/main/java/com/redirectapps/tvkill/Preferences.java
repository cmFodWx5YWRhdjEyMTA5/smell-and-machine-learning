// isComment
package com.redirectapps.tvkill;

import android.os.Bundle;
import android.preference.PreferenceActivity;

public class isClassOrIsInterface extends PreferenceActivity {

    @Override
    protected void isMethod(Bundle isParameter) {
        super.isMethod(isNameExpr);
        isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr);
    }
}
