// isComment
package com.redirectapps.tvkill;

import android.app.Fragment;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class isClassOrIsInterface extends Fragment {

    public View isMethod(LayoutInflater isParameter, ViewGroup isParameter, Bundle isParameter) {
        View isVariable = isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr, isNameExpr, true);
        // isComment
        isMethod(isNameExpr);
        return isNameExpr;
    }

    // isComment
    private void isMethod(View isParameter) {
        // isComment
        if (isNameExpr.isMethod(isMethod()).isMethod("isStringConstant", true))
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr).isMethod(isNameExpr.isFieldAccessExpr);
        else
            isNameExpr.isMethod(isNameExpr.isFieldAccessExpr.isFieldAccessExpr).isMethod(isNameExpr.isFieldAccessExpr);
    }

    @Override
    public void isMethod() {
        super.isMethod();
        // isComment
        isMethod(isMethod());
    }
}
