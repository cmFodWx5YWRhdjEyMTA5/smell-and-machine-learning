// isComment
package com.redirectapps.tvkill;

import android.app.Application;
import android.test.ApplicationTestCase;

/**
 * isComment
 */
public class isClassOrIsInterface extends ApplicationTestCase<Application> {

    public isConstructor() {
        super(Application.class);
    }
}
